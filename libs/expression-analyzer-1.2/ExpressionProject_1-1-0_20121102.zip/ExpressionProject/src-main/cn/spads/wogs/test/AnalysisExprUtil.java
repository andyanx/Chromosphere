/**
 * 公式解析系统
 * ExpEva.java independently from 2012-10-21 上午11:18:03
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.test;
import java.util.Stack;
/**
 * 分析用堆栈解析算术表达式
 * 然后利用堆栈进行四则算术
 * TODO summary..
 * This ExpEva TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author WangXP
 * @version		1.1.0, 2012-10-21
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class AnalysisExprUtil
{
	// Programmer comments for whole class.

	private static final char SYMBOL_LEFT = '(';
	private static final char SYMBOL_RIGHT = ')';
	private static final char SYMBOL_ADD = '+';
	private static final char SYMBOL_SUB = '-';
	private static final char SYMBOL_MUL = '*';
	private static final char SYMBOL_DIV = '/';
	
	private static Stack<Object> stack = new Stack<Object>();
	private static StringBuffer express = new StringBuffer();
	
	/***
	 * (A-B)*C+D-E/F
	 * @return
	 */
	public static String strInitConvert(String expressStr)
	{
		if (expressStr==null?true:expressStr.length()==0)
		{
			return "0";
		}
		
		// 检查表达式中括号格式是否正确
		if (checkFormatSymbol(expressStr))
		{
			for(int i = 0; i < expressStr.length(); i ++)
			{
				char temp = expressStr.charAt(i);
				if (checkOperator(temp))
				{
					if (temp == SYMBOL_LEFT)
					{
						stack.push(temp);
					}
					else if (temp == SYMBOL_RIGHT)
					{
						// 思考1,如果表达式中出现多元数据操作情况，
						// (A+B-C)就要考虑从栈顶移出数据知道是’(’时候
						
						while(!stack.isEmpty())
						{
							if (convertObjectToChar(stack.peek()) == SYMBOL_LEFT)
							{
								stack.pop();
								break;
							}
							else
							{
								express.append(stack.pop());
							}
						}
					}
					else
					{
						int tempLevel = validateLevel(temp);
						int stackLevel;
						if (!stack.isEmpty())
						{
							stackLevel = validateLevel(convertObjectToChar(stack.peek()));
						}
						else
						{
							stackLevel = 0;
						}
						
						if (tempLevel > stackLevel)
						{
							stack.push(temp);
						}
						else if (tempLevel == stackLevel)
						{
							while(!stack.isEmpty())
							{
								if (validateLevel(convertObjectToChar(stack.peek())) == tempLevel)
								{
									express.append(stack.pop());
									stack.push(temp);
									break;
								}
							}
						}
						else
						{
							express.append(stack.pop());
							stack.push(temp);
						}
					}
				}
				else
				{
					express.append(temp);
				}
			}
			
			while(!stack.isEmpty())
			{
				express.append(convertObjectToChar(stack.pop()));
			}
		}
		System.out.println(express);
		return getCalResult(express);
	}
	
	public static String getCalResult(StringBuffer sb)
	{
		char[] c = sb.toString().toCharArray();
		stack.clear();
		for(int i = 0 ; i < c.length; i ++)
		{
			char tempData = c[i];
			
			if (checkOperator(tempData))
			{
				//运算符
				double value2 = convertObjectToInt(stack.pop());
				double value1 = convertObjectToInt(stack.pop());
				calc(tempData, value1, value2);
			}
			else
			{
				//操作数
				stack.push(tempData);
			}
		}
		
		return stack.pop().toString();
	}
	
	public static void calc(char operator, double value1, double value2)
	{
		double newValue = 0.0;
		
		switch (operator)
		{
		case SYMBOL_ADD:
			newValue = value1 + value2;
			break;
		case SYMBOL_SUB:
			newValue = value1 - value2;
			break;
		case SYMBOL_MUL:
			newValue = value1 * value2;
			break;
		case SYMBOL_DIV:
			newValue = value1 / value2;;
			break;
		}
		
		stack.push(String.valueOf(newValue));
	}
	
	public static double convertObjectToInt(Object obj)
	{
		return Double.valueOf(obj.toString());
	}
	
	public static char convertObjectToChar(Object obj)
	{
		return obj.toString().charAt(0);
	}
	
	public static int getOperatorCount(char ch)
	{
		int count = 0;
		
		switch (ch)
		{
		case SYMBOL_ADD:
			count = 2;
			break;
		case SYMBOL_SUB:
			count = 2;
			break;
		case SYMBOL_MUL:
			count = 2;
			break;
		case SYMBOL_DIV:
			count = 2;
			break;
		}
		
		return count;
	}
	
	public static int validateLevel(char ch)
	{
		int level = 0;
		
		switch (ch)
		{
		case SYMBOL_ADD:
			level = 1;
			break;
		case SYMBOL_SUB:
			level = 1;
			break;
		case SYMBOL_MUL:
			level = 2;
			break;
		case SYMBOL_DIV:
			level = 2;
			break;
		}
		
		return level;
	}
	
	/**
	 * 检查表达式中括号格式是否正确
	 * @return
	 */
	public static boolean checkFormatSymbol(String expressStr)
	{
		int symbolCount = 0;
		
		for(int i = 0; i < expressStr.length(); i ++)
		{
			String temp = String.valueOf(expressStr.charAt(i));
			if (temp.equals("("))
			{
				symbolCount ++;
			}
			if (temp.equals(")"))
			{
				symbolCount --;
			}
		}
		
		return symbolCount == 0? true:false;
	}
	
	/**
	 * 检查当前字符是否运算符
	 * @param ch
	 * @return
	 */
	public static boolean checkOperator(char ch)
	{
		boolean isOperator = false;
		char[] operators = { '+', '-', '*', '/', '(', ')' };
		for (int i = 0; i < operators.length; i ++)
		{
			if (operators[i] == ch)
			{
				isOperator = true;
				break;
			}
		}
		
		return isOperator;
	}
	
	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		String str2 = "(3+6)*5";
		System.out.println(AnalysisExprUtil.strInitConvert(str2));
	}
}
