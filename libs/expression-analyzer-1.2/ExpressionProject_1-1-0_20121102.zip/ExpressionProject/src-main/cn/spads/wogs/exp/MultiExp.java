/**
 * 公式解析系统
 * MultiExpression.java independently from 2012-10-11 下午03:30:21
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

import static cn.spads.wogs.exp.Expression.Type.MULTIPLE_EXPRESSION;
import static cn.spads.wogs.exp.Operator.FACTORIAL;
import static cn.spads.wogs.exp.Operator.NEGATIVE;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

/**
 * <b>多项式</b><br/>
 * 多项式在英迪曼公式框架中，被理解为一堆 {@link Item} 的有序排列。这些 Item 包括
 * 表达式和运算符。
 * TODO summary..
 * This MultiExpression TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-11
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class MultiExp extends VisibleItem implements Expression
{
	// Programmer comments for whole class.

	/** 多项式是否在括号中 */
	private boolean inBracket;
	/** 多项式各项以及运算符 */
	private List<Item> items;

	MultiExp(String text, boolean inBracket)
	{
		super(text);
		this.inBracket = inBracket;
		this.items = new LinkedList<Item>();
	}

	/**
	 * 增加多项式的段
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param item
	 * @exception
	 */
	public void addItem(Item item)
	{
		if (items == null) throw new ExpException("Null expression item.");
		this.items.add(item);
	}

	/**
	 * 
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public int itemsCount()
	{
		return this.items.size();
	}

	/**
	 * 获取表达式类型
	 * 多项式的类型为 {@link #MULTIPLE_EXPRESSION} 。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.Expression#getType()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	public Type getType()
	{
		return MULTIPLE_EXPRESSION;
	}

	/**
	 * 获取公式段迭代器
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public Iterator<Item> getItemIterator()
	{
		return this.items.iterator();
	}

	/**
	 * <b>生成显示文本</b><br/>
	 * 多项式每一个公式段之间，由空格分开。多项式前后会由括号包括。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see java.lang.Object#toString()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	protected String generateDispText()
	{
		StringBuilder dispTextBuilder = new StringBuilder();
		boolean appendBracket = this.inBracket && this.items.size() > 1;
		if (appendBracket) dispTextBuilder.append('(');
		Item item = null;
		Iterator<Item> iterator = this.getItemIterator();
		while (iterator.hasNext())
		{
			item = iterator.next();
			if (item == FACTORIAL)
				dispTextBuilder.deleteCharAt(dispTextBuilder.length() - 1);
			dispTextBuilder.append(item);
			if (item != NEGATIVE) dispTextBuilder.append(' ');
		}
		dispTextBuilder.deleteCharAt(dispTextBuilder.length() - 1);
		if (appendBracket) dispTextBuilder.append(')');
		return dispTextBuilder.toString();
	}
}
