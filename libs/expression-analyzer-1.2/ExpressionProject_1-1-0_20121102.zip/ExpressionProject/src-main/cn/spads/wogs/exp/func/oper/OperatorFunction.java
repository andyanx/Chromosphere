/**
 * 公式解析系统
 * OperatorFunction.java independently from 2012-10-24 上午10:51:20
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func.oper;

import java.util.List;

import cn.spads.wogs.exp.ExpException;
import cn.spads.wogs.exp.ExpValue;
import cn.spads.wogs.exp.Operator;
import cn.spads.wogs.exp.func.Function;


/**
 * 运算符函数
 * TODO summary..
 * This OperatorFunction TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-24
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public abstract class OperatorFunction implements Function
{
	// Programmer comments for whole class.

	/**
	 * 运算符函数求值
	 * 本方法抽取了函数运算参数中的第一个值，取其值理解为运算符。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.func.Function#evaluate(cn.spads.wogs.exp.ExpValue[])
	 * @see
	 * @param params
	 * @return
	 * @exception
	 */
	@Override
	public ExpValue evaluate(ExpValue... params)
	{
		if (params.length < 2 || params[0] == null)
			throw new ExpException(
					"Operation wrong params' count: " + params.length);
		Object operObj = params[0].value();
		if (operObj == null || !(operObj instanceof Operator))
			throw new ExpException("Operator type error.");
		Operator oper = (Operator) operObj;
		ExpValue[] operatingParams = new ExpValue[params.length - 1];
		System.arraycopy(
				params, 1, operatingParams, 0, operatingParams.length);
		return this.evaluate(oper, operatingParams);
	}

	/**
	 * 获取对应的操作符
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	abstract public List<Operator> getCorrespondingOperators();

	/**
	 * 具体运算符函数的求值方法
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param oper
	 * @param params
	 * @return
	 * @exception
	 */
	abstract public ExpValue evaluate(Operator oper, ExpValue... params);
}
