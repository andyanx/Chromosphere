/**
 * 公式解析系统
 * Addition.java independently from 2012-10-21 下午04:13:12
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func.oper;

import static cn.spads.wogs.exp.ExpValue.ValueType.BOOL;
import static cn.spads.wogs.exp.ExpValue.ValueType.FLOAT;
import static cn.spads.wogs.exp.ExpValue.ValueType.INT;
import static cn.spads.wogs.exp.ExpValue.ValueType.NULL;
import static cn.spads.wogs.exp.Operator.FACTORIAL;
import static cn.spads.wogs.exp.Operator.NEGATIVE;


import java.util.ArrayList;
import java.util.List;

import cn.spads.wogs.exp.ExpException;
import cn.spads.wogs.exp.ExpValue;
import cn.spads.wogs.exp.Operator;
import cn.spads.wogs.exp.ExpValue.ValueType;
import cn.spads.wogs.exp.func.Function;
import cn.spads.wogs.lang.NumberTool;


/**
 * 单值转换
 * TODO summary..
 * This Addition TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-21
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class Rotation extends OperatorFunction implements Function
{
	// Programmer comments for whole class.

	/**
	 * 单值转换操作符列表
	 */
	private List<Operator> rotationOperators;

	public Rotation()
	{
		this.rotationOperators = new ArrayList<Operator>(2);
		this.rotationOperators.add(NEGATIVE);
		this.rotationOperators.add(FACTORIAL);
	}

	/**
	 * 获取单值转换操作符
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public List<Operator> getCorrespondingOperators()
	{
		return this.rotationOperators;
	}

	/**
	 * 自变求值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.func.Function#evaluate(cn.spads.wogs.exp.ExpValue[])
	 * @see
	 * @param params
	 * @return
	 * @exception
	 */
	@Override
	public ExpValue evaluate(Operator oper, ExpValue... params)
	{
		// 提取参数值，检查参数情况
		if (params.length != 1 || params[0] == null)
			throw new ExpException("Rotation wrong params.");
		ValueType type1 = params[0].type();
		Object value1 = params[0].value();
		if (value1 == null && type1 != NULL) return params[0];

		// 不同运算符执行不同的方法
		ExpValue result = null;
		switch (oper)
		{
			case NEGATIVE:
				result = this.negate(type1, value1);
				break;
			case FACTORIAL:
				result = this.factorial(type1, value1);
				break;
		}

		// 如果不是自变运算符，则不进行运算
		return result != null ? result : params[0];
	}

	/**
	 * 求负
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param base
	 * @return
	 * @exception
	 */
	private ExpValue negate(ValueType type1, Object value1)
	{
		// 有效类型
		switch (type1)
		{
			case INT:
				long baseInt = ((Long) value1).longValue();
				return ExpValue.valueOf(INT, -1 * baseInt);
			case FLOAT:
				double baseFloat = ((Double) value1).doubleValue();
				return ExpValue.valueOf(FLOAT, -1 * baseFloat);
			case BOOL:
				boolean baseBool = ((Boolean) value1).booleanValue();
				return ExpValue.valueOf(BOOL, !baseBool);
			case NULL:
				return null;
		}
		throw new ExpException(
				"Data type " + type1 + " does not support negation.");
	}

	/**
	 * 求阶乘
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param type1
	 * @param value1
	 * @return
	 * @exception
	 */
	private ExpValue factorial(ValueType type1, Object value1)
	{
		// 只有整数才能进行阶乘
		if (type1 != INT)
			throw new ExpException(
					"Data type " + type1 + " does not support factorial.");
		int base = ((Long) value1).intValue();
		return ExpValue.valueOf(INT, NumberTool.factorial(base));
	}
}
