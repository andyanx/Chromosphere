/**
 * 公式解析系统
 * Random.java independently from 2012-10-28 上午11:33:39
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func;

import cn.spads.wogs.exp.ExpValue;
import static cn.spads.wogs.exp.ExpValue.ValueType.FLOAT;
import static cn.spads.wogs.exp.ExpValue.ValueType.INT;


/**
 * 随机函数
 * TODO summary..
 * This Random TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-28
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class Random implements Function
{
	// Programmer comments for whole class.

	/**
	 * <b>计算随机函数的值</b><br/>
	 * 如果没有参数，或参数类型非数值，则返回 0 - 1 之间的随机浮点数。
	 * 如果有参数，则返回 0 - 参数值之间的随机整数。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.func.Function#evaluate(cn.spads.wogs.exp.ExpValue[])
	 * @see
	 * @param params
	 * @return
	 * @exception
	 */
	@Override
	public ExpValue evaluate(ExpValue... params)
	{
		ExpValue limit;
		java.util.Random randomEngin = new java.util.Random();
		if (params.length == 0
				|| !((limit = params[0]).value() instanceof Number))
			return ExpValue.valueOf(FLOAT, randomEngin.nextDouble());
		long max = ((Number) limit.value()).longValue();
		return ExpValue.valueOf(INT, Math.abs(randomEngin.nextLong() % max));
	}
}
