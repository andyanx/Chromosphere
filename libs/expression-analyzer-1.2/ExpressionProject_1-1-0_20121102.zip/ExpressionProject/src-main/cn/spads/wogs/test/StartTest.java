/**
 * 公式解析系统
 * StartTest.java independently from 2012-11-2 上午10:28:30
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.test;

import cn.spads.wogs.exp.Evaluator;
import cn.spads.wogs.exp.EvaluatorFactory;
import cn.spads.wogs.exp.ExpValue;

/**
 * 初始的执行
 * TODO summary..
 * This StartTest TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-11-2
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class StartTest
{
	// Programmer comments for whole class.

	static public void main(String[] arguments)
	{
		String form = "Result ?= TOGETHER(\"result\", 19 + 3 ^ 4)";
		Evaluator eva = EvaluatorFactory.INST.getEvaluator(form);
		ExpValue result = eva.evaluate();
		System.out.println("result = " + result);
	}
}
