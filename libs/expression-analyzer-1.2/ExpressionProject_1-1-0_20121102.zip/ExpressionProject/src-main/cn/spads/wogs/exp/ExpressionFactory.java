/**
 * 公式解析系统
 * ExpressionFactory.java independently from 2012-10-11 上午11:38:33
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

import static cn.spads.wogs.exp.ExpValue.ValueType.BOOL;
import static cn.spads.wogs.exp.ExpValue.ValueType.DATA;
import static cn.spads.wogs.exp.ExpValue.ValueType.FLOAT;
import static cn.spads.wogs.exp.ExpValue.ValueType.INT;
import static cn.spads.wogs.exp.ExpValue.ValueType.NULL;
import static cn.spads.wogs.exp.ExpValue.ValueType.TEXT;
import static cn.spads.wogs.exp.Expression.Type.FUNCTION;
import static cn.spads.wogs.exp.Expression.Type.MONOMIAL;
import static cn.spads.wogs.exp.Expression.Type.MULTIPLE_EXPRESSION;
import static cn.spads.wogs.exp.Expression.Type.VARIABLE;
import static cn.spads.wogs.exp.Operator.MINUS;
import static cn.spads.wogs.exp.Operator.NEGATIVE;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

/**
 * <b>表达式工厂</b><br/>
 * 表达式工厂负责产出表达式对象。其通过表达式文本的一些特性，逐字符审查表达式内容，
 * 将其解析成对应的表达式，并将生成的表达式对象返回。
 * 本类采取的算法，分离了检查公式类型与生成公示对象这二个步骤。此二步骤都需要逐一
 * 审查公式文本的每一个字符。并且对于公式中的独立部分，会分别进行再次遍历字符。所以
 * 说，本工厂并不是一个专门注重运行效率的公式生成器，但针对公式逻辑概念进行了易于
 * 理解的抽象，适合更改。使用时如可能，应配合公式解析缓存。
 * TODO summary..
 * This ExpressionFactory TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-11
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class ExpressionFactory
{
	// Programmer comments for whole class.

	/**
	 * <b>单例对象</b><br/>
	 * 本对象的设计，考虑到日后支持多重运算符含义。如果有多种运算符集，可做成枚举。
	 * 如果需要注入运算符集，也可以取消单例。
	 */
	static public final ExpressionFactory INST = new ExpressionFactory();

	/**
	 * 操作符首字符检索表
	 * 此字典用于快速识别操作符。由于可能存在多个操作符具有相同的首字符，所以每一个
	 * 首字符都对应一个操作符列表。
	 */
	private Map<Character, List<Operator>> operatorFirstCharDict;
	/**
	 * 表达式对象池
	 */
	private Map<String, Expression> expressionPool;

	/**
	 * 构造方法中根据操作符的情况，初始化了操作符首字符字典。
	 * TODO summary..
	 * The object will be created TODO ...
	 * @see
	 */
	private ExpressionFactory()
	{
		this.registerOperatorFirstCharDic();
		this.expressionPool = Collections.synchronizedMap(
				new HashMap<String, Expression>());
	}

	/**
	 * 注册操作符首字符检索表
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @exception
	 */
	private void registerOperatorFirstCharDic()
	{
		this.operatorFirstCharDict = new HashMap<Character, List<Operator>>();
		for (Operator opera: Operator.values())
		{
			char firstChar = opera.getText().charAt(0);
			List<Operator> sameCharOperators =
					this.operatorFirstCharDict.get(firstChar);
			if (sameCharOperators == null)
				this.operatorFirstCharDict.put(
						firstChar,
						sameCharOperators = new ArrayList<Operator>(3)
					);
			sameCharOperators.add(opera);
		}
	}

	/**
	 * 通过公式文本，获取公式
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expText
	 * @return
	 * @exception
	 */
	public Expression getExpressionFromText(String expText)
	{
		Expression expression = this.expressionPool.get(expText);
		if (expression == null)
		{
			expression = this.loadText(expText, false);
			if (this.expressionPool.size() >= 100) this.expressionPool.clear();
			this.expressionPool.put(expText, expression);
		}
		return expression;
	}

	/**
	 * 加载公式文本，得到表达式。
	 * 要求传入的 expressionText 参数已经去除过首尾空格。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expressionText
	 * @return
	 * @exception
	 */
	private Expression loadText(String expText, boolean inBracket)
	{
		// 1 装载公式文本
		if (expText == null || expText.trim().length() == 0)
			throw new ExpException("Null or empty expression.");

		// 2 获取公式类型
		Expression.Type expType = this.checkExpType(expText);

		// 3 根据公式类型，调用不同的解析方法
		switch (expType)
		{
			case VARIABLE:
				return this.loadVariableText(expText);
			case MONOMIAL:
				return this.loadMonomialText(expText);
			case FUNCTION:
				return this.loadFunctionText(expText);
			case MULTIPLE_EXPRESSION:
				MultiExp expression = this.loadMultiExpText(expText, inBracket);
				if (expression.itemsCount() != 1) return expression;
				Item singleItem = expression.getItemIterator().next();
				if (singleItem instanceof Expression)
					return (Expression) singleItem;
		}
		throw new ExpException("Unrecognized expression type: ".concat(expText));
	}

	/**
	 * 检查公式文本对应的公式类型，已决定调用不同的公式识别方法。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expressionText	由调用者保证 expText 不为空，且已经被 trim()
	 * @return
	 * @exception
	 */
	private Expression.Type checkExpType(String expText)
	{
		// 如果是特殊值，则认定为单项式。
		if (expText.equals("true") || expText.equals("false")
				|| expText.equals("null"))
			return MONOMIAL;

		// 是否连续符合函数、变量名要求
		boolean consecutiveFunctionName = true;
		// 有没有函数的可能（开始是连续函数名，然后紧接着括号则为有可能，否则无可能）
		boolean functionPosibility = false;
		// 包括运算符
		boolean containsOperator = false;
		// 括号层级
		int bracketCount = 0;
		// 是否为整括多项式
		boolean wholeMultipleExpression = false;

		// 是否在引号中
		boolean inQuote = false;

		char[] expChars = expText.toCharArray();
		char thisChar = 0;
		for (int index = -1; ++index != expChars.length; )
		{
			thisChar = expChars[index];

			// 1 对于在引号中的处理
			if (inQuote)
			{
				if (thisChar == '"' && expChars[index - 1] != '\\')
					inQuote = false;
				continue;
			}

			// 2 如果是函数、变量名字符，则开始检查下一个字符
			if (this.checkNameChar(thisChar)) continue;

			// 3 如果不是函数、变量名字符，则检查最初始的函数、变量名是否还未中断
			if (consecutiveFunctionName)
			{
				consecutiveFunctionName = false;
				if (index != 0 && thisChar == '(')
				{
					functionPosibility = true;
					bracketCount++;
					continue;
				}
			}

			// 4 根据字符判断公式情况
			switch (thisChar)
			{
				case '(':
					bracketCount++;
					if (index == 0) wholeMultipleExpression = true;
					continue;
				case ')':
					bracketCount--;
					if (bracketCount == 0 && index != expChars.length - 1)
					{
						functionPosibility = false;
						wholeMultipleExpression = false;
					}
					continue;
				case '"':
					inQuote = true;
					continue;
				default:
					if (!containsOperator && checkOperator(thisChar))
						containsOperator = true;
			}
		}
		// 5 根据之前记录的判断情况，决定公式类型
		if (functionPosibility
				&& bracketCount == 0 && expChars[expChars.length - 1] == ')')
			return FUNCTION;
		if (consecutiveFunctionName) return VARIABLE;
		if (containsOperator || wholeMultipleExpression)
			return MULTIPLE_EXPRESSION;
		return MONOMIAL;
	}

	/**
	 * 检测字符是否属于公式命名可用字符。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param c
	 * @return
	 * @exception
	 */
	private boolean checkNameChar(char c)
	{
		return c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' || c == '_';
	}

	/**
	 * 检测字符是否属于空白符。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param c
	 * @return
	 * @exception
	 */
	private boolean checkBlankChar(char c)
	{
		return c == ' ' || c == '\t' || c == '\n' || c == '\r';
	}

	/**
	 * 加载纯粹的函数式。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expText
	 * @return
	 * @exception
	 */
	private FunctionExp loadFunctionText(String expText)
	{
		int funcNameLength = expText.indexOf('(');
		String funcName = expText.substring(0, funcNameLength);
		String paramText = expText.substring(funcNameLength + 1, expText.length() - 1);
		FunctionExp functionExp =
				new FunctionExp(expText, funcName);
		this.loadParamText(functionExp, paramText);
		return functionExp;
	}

	/**
	 * 解析、加载函数参数表达式。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param functionExp
	 * @param paramText
	 * @exception
	 */
	private void loadParamText(FunctionExp functionExp, String paramText)
	{
		// 如果没有参数
		if (paramText.trim().length() == 0) return;

		// 如果有参数
		boolean inQuote = false;
		int bracketCount = 0;
		int braceCount = 0;

		char[] expChars = paramText.toCharArray();
		char thisChar = 0;
		int lastIndex = 0;
		String thisParamStr;
		for (int index = -1; ++index != expChars.length; )
		{
			thisChar = expChars[index];

			// 1 对于在引号中的处理
			if (inQuote)
			{
				if (thisChar == '"' && expChars[index - 1] != '\\')
					inQuote = false;
				continue;
			}

			// 2 对于其它字符的处理
			switch (thisChar)
			{
				case '{':
				case '[': braceCount++; continue;
				case '}':
				case ']': braceCount--; continue;
				case '(': bracketCount++; continue;
				case ')': bracketCount--; continue;
				case '"': inQuote = true; continue;
			}

			// 3 对于不在括号中逗号的处理
			if (thisChar == ',' && bracketCount == 0 && braceCount == 0)
			{
				thisParamStr = paramText.substring(lastIndex, index).trim();
				functionExp.addParam(this.loadText(thisParamStr, false));
				lastIndex = index + 1;
			}
		}
		// 4 最终，追加最后一个参数
		thisParamStr = paramText.substring(lastIndex).trim();
		if (thisParamStr.length() != 0)
			functionExp.addParam(this.loadText(thisParamStr, false));
	}

	/**
	 * 加载纯粹的变量式
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expText
	 * @return
	 * @exception
	 */
	private Variable loadVariableText(String expText)
	{
		return new Variable(expText);
	}

	/**
	 * 加载单项式文本。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expText
	 * @return
	 * @exception
	 */
 	private Monomial loadMonomialText(String expText)
	{
		char firstChar = expText.charAt(0);
		switch (firstChar)
		{
			case '{':
			case '[':
				return new Monomial(expText, DATA);
			case '"':
				return new Monomial(expText, TEXT);
			case 'n':
				if (expText.equals("null")) return new Monomial(expText, NULL);
				break;
			case 't':
			case 'f':
				if (expText.equals("true") || expText.equals("false"))
					return new Monomial(expText, BOOL);
		}
		if (firstChar <= '9' && firstChar >= '0')
			return new Monomial(
					expText,
					expText.indexOf('.') == -1 ? INT : FLOAT
				);
		throw new ExpException("Unrecognized monomial: ".concat(expText));
	}

	/**
	 * 加载多项式文本。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expText
	 * @return
	 * @exception
	 */
	private MultiExp loadMultiExpText(String expText, boolean inBracket)
	{
		char[] expChars = expText.toCharArray();

		MultiExp multiExp = new MultiExp(expText, inBracket);

		// 空白符开头
		boolean pureBegining = true;
		// 小括号个数
		int bracketCount = 0;
		// 是否在引号中
		boolean inQuote = false;
		// 是否在一个独立段中
		boolean inSection = false;

		int nextStartIndex = 0;
		char thisChar = 0;
		for (int index = -1; ++index != expChars.length; )
		{
			thisChar = expChars[index];

			// 1 对于引号的处理。引号中任何符号都不产生原有效果。
			if (inQuote && thisChar != '"') continue;
			if (thisChar == '"'
					&& (index == 0 ? true : expChars[index - 1] != '\\'))
			{
				inQuote = ! inQuote;
				continue;
			}

			// 2 对于括号的处理
			// 如果是首括号，则进入独立段方式；否则仅为括号层数增加。
			if (thisChar == '(' && bracketCount++ == 0)
			{
				inSection = true;
				// 只有空白符构成的开头，意味着此括号伪多项式括号，而非函数括号
				if (pureBegining) nextStartIndex = index + 1;
			}
			// 如果已经在独立段中，只需要考虑括号增减以及独立段完成
			if (inSection)
			{
				if (thisChar == ')' && --bracketCount == 0)
				{
					inSection = false;
					// 只有空白符构成的开头，意味着此括号伪多项式括号，而非函数括号
					int sectionEndIndex = index + (pureBegining ? 0 : 1);
					String thisSection = expText.substring(
							nextStartIndex, sectionEndIndex).trim();
					multiExp.addItem(this.loadText(thisSection, pureBegining));
					pureBegining = true;
					nextStartIndex = index + 1;
				}
				continue;
			}

			// 3 对于变量、函数名的处理
			if (pureBegining && !this.checkBlankChar(thisChar))
				pureBegining = false;

			// 4 对于运算符的处理
			if (!this.checkOperator(thisChar)) continue;
			String expBeforeOperator =
					expText.substring(nextStartIndex, index).trim();
			boolean isUnary = expBeforeOperator.length() == 0;
			Operator operator = this.fetchOperator(isUnary, expText, index);
			if (!isUnary)
				multiExp.addItem(this.loadText(expBeforeOperator, false));
			multiExp.addItem(operator);
			index = index + operator.getText().length() - 1;
			nextStartIndex = index + 1;
		}
		// 5 追加多项式的最后一段
		if (nextStartIndex != expChars.length)
		{
			String lastSection =
					expText.substring(nextStartIndex).trim();
			multiExp.addItem(this.loadText(lastSection, false));
		}
		return multiExp;
	}

	/**
	 * 检查是否为运算符种类。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param operator
	 * @return
	 * @exception
	 */
	private boolean checkOperator(char checkedChar)
	{
		return this.operatorFirstCharDict.get(checkedChar) != null;
	}
	/**
	 * 获取运算符
	 * 要保证 expText 能够读取到第 startIndex 位的字符。
	 * @param isUnary
	 * @param expText
	 * @param startIndex
	 * @return
	 */
	private Operator fetchOperator(
			boolean isUnary, String expText, int startIndex)
	{
		char firstChar = expText.charAt(startIndex);
		List<Operator> operators = this.operatorFirstCharDict.get(firstChar);
		Iterator<Operator> operatorIterator = operators.iterator();
		while (operatorIterator.hasNext())
		{
			Operator operator = operatorIterator.next();
			String operatorText = operator.getText();
			int operatorLength = operatorText.length();
			if (startIndex + operatorLength > expText.length()) continue;
			String expSectionText = expText.substring(
					startIndex, startIndex + operatorText.length());
			if (expSectionText.equals(operatorText))
			{
				// 这里是特殊的负号/减号转换逻辑。此处要求减号和负号形式一样。
				if (operator == NEGATIVE || operator == MINUS)
					return isUnary ? NEGATIVE : MINUS;
				return operator;
			}
		}
		throw new ExpException("Unrecognized operator.");
	}
}
