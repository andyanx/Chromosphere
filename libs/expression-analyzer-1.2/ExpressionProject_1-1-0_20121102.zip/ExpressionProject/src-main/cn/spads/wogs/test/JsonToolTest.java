/**
 * 公式解析系统
 * JsonToolTest.java independently from 2012-10-29 下午02:08:07
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.test;

import java.util.Calendar;

import cn.spads.wogs.lang.JsonBuilder;
import cn.spads.wogs.lang.JsonParser;


/**
 * TODO summary..
 * This JsonToolTest TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-29
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class JsonToolTest
{
	// Programmer comments for whole class.

	/**
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param args
	 * @exception
	 */
	public static void main(String[] args)
	{
		String jsonStr = "[{\"people\": {\"name\": \"Shane\", \"age\": 28}, \"money\": 1000},{\"people\": {\"name\": \"Dioskouri\", \"age\": 26}, \"money\": 1001}]";
		System.out.println("原 Json 为：" + jsonStr);
		Object dataObj = null;
		int loop = 300000;
		long start = Calendar.getInstance().getTimeInMillis();
		for (int index = -1; ++index != loop; )
		{
			dataObj = JsonParser.getInstance().parseJson(jsonStr);
			jsonStr = JsonBuilder.getInstance().buildJson(dataObj);
		}
		long end = Calendar.getInstance().getTimeInMillis();
		System.out.println("运行 " + loop + " 次 Json 互转，用时 " + (end - start) + "ms.");
		System.out.println("最终结果为：" + jsonStr);
	}
}
