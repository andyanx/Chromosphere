/**
 * 公式解析系统
 * Addition.java independently from 2012-10-21 下午04:13:12
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func.oper;

import static cn.spads.wogs.exp.ExpValue.ValueType.FLOAT;
import static cn.spads.wogs.exp.ExpValue.ValueType.INT;
import static cn.spads.wogs.exp.ExpValue.ValueType.NULL;
import static cn.spads.wogs.exp.Operator.DIVISION;
import static cn.spads.wogs.exp.Operator.MINUS;
import static cn.spads.wogs.exp.Operator.MOD;
import static cn.spads.wogs.exp.Operator.MULTIPLE;
import static cn.spads.wogs.exp.Operator.PLUS;
import static cn.spads.wogs.exp.Operator.POWER;

import java.util.ArrayList;
import java.util.List;

import cn.spads.wogs.exp.ExpException;
import cn.spads.wogs.exp.ExpValue;
import cn.spads.wogs.exp.Operator;
import cn.spads.wogs.exp.ExpValue.ValueType;
import cn.spads.wogs.exp.func.Function;
import cn.spads.wogs.lang.NumberTool;


/**
 * 算术运算函数
 * TODO summary..
 * This Addition TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-21
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class Arithmetic extends OperatorFunction implements Function
{
	// Programmer comments for whole class.
	/**
	 * 算术运算操作符列表
	 */
	private List<Operator> arithmeticOperators;

	public Arithmetic()
	{
		this.arithmeticOperators = new ArrayList<Operator>(6);
		this.arithmeticOperators.add(POWER);
		this.arithmeticOperators.add(MULTIPLE);
		this.arithmeticOperators.add(DIVISION);
		this.arithmeticOperators.add(MOD);
		this.arithmeticOperators.add(PLUS);
		this.arithmeticOperators.add(MINUS);
	}

	/**
	 * 获取算术运算操作符
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public List<Operator> getCorrespondingOperators()
	{
		return this.arithmeticOperators;
	}

	/**
	 * 算术运算求值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.func.Function#evaluate(cn.spads.wogs.exp.ExpValue[])
	 * @see
	 * @param params
	 * @return
	 * @exception
	 */
	@Override
	public ExpValue evaluate(Operator oper, ExpValue... params)
	{
		// 1 运算参数准备
		// 检查参数情况
		if (params.length != 2 || params[0] == null || params[1] == null)
			throw new ExpException("Arithmetic params wrong.");
		ValueType type1 = params[0].type();
		Object value1Obj = params[0].value();
		ValueType type2 = params[1].type();
		Object value2Obj = params[1].value();
		// 如果参数类型不是数值型，或者有 null 值，认为不能进行算术运算
		if (type1 != INT && type1 != FLOAT && type2 != INT && type2 != FLOAT
				|| value1Obj == null || value2Obj == null
				|| !(value1Obj instanceof Number) || !(value2Obj instanceof Number))
			throw new ExpException("Arithmetic params wrong.");
		// 抽取运算用数
		boolean allInt = type1 == INT && type2 == INT;
		Number value1 = (Number) value1Obj;
		Number value2 = (Number) value2Obj;

		// 2 不同运算符执行不同的方法
		switch (oper)
		{
			// 乘方运算
			case POWER: return this.power(allInt, value1, value2);

			// 乘法运算
			case MULTIPLE: return this.multiply(allInt, value1, value2);

			// 除法运算
			case DIVISION: return this.divide(allInt, value1, value2);

			// 求余运算
			case MOD: return this.askMod(allInt, value1, value2);

			// 加法运算
			case PLUS: return this.add(allInt, value1, value2);

			// 减法运算
			case MINUS: return this.reduce(allInt, value1, value2);
		}

		// 3 如果不是逻辑运算符，则不进行运算，返回空值
		return ExpValue.valueOf(NULL, null);
	}

	/**
	 * 次方运算
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param type1
	 * @param value1
	 * @param type2
	 * @param value2
	 * @return
	 * @exception
	 */
	private ExpValue power(boolean allInt, Number value1, Number value2)
	{
		// 如果都是整数，使用简易求幂方式
		if (allInt)
			return ExpValue.valueOf(INT, NumberTool.intPow(
					value1.intValue(), value2.intValue()));

		// 否则使用通用的浮点数求幂
		return ExpValue.valueOf(FLOAT, Math.pow(
				value1.doubleValue(), value2.doubleValue()));
	}

	/**
	 * 乘法运算
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param allInt
	 * @param value1
	 * @param value2
	 * @return
	 * @exception
	 */
	private ExpValue multiply(boolean allInt, Number value1, Number value2)
	{
		// 如果都是整数，使用整数乘法
		if (allInt)
			return ExpValue.valueOf(
					INT, value1.longValue() * value2.longValue());

		// 否则使用通用的浮点数乘法
		return ExpValue.valueOf(
				FLOAT, value1.doubleValue() * value2.doubleValue());
	}

	/**
	 * 除法运算
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param allInt
	 * @param value1
	 * @param value2
	 * @return
	 * @exception
	 */
	private ExpValue divide(boolean allInt, Number value1, Number value2)
	{
		// 如果都是整数，使用整数除法
		if (allInt)
			return ExpValue.valueOf(
					INT, value1.longValue() / value2.longValue());

		// 否则使用通用的浮点数除法
		return ExpValue.valueOf(
				FLOAT, value1.doubleValue() / value2.doubleValue());
	}

	/**
	 * 求余运算
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param allInt
	 * @param value1
	 * @param value2
	 * @return
	 * @exception
	 */
	private ExpValue askMod(boolean allInt, Number value1, Number value2)
	{
		// 如果都是整数，使用整数求余
		if (allInt)
			return ExpValue.valueOf(
					INT, value1.longValue() % value2.longValue());

		// 否则使用通用的浮点数求余
		return ExpValue.valueOf(
				FLOAT, value1.doubleValue() % value2.doubleValue());
	}

	/**
	 * 加法运算
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param allInt
	 * @param value1
	 * @param value2
	 * @return
	 * @exception
	 */
	private ExpValue add(boolean allInt, Number value1, Number value2)
	{
		// 如果都是整数，使用整数加法
		if (allInt)
			return ExpValue.valueOf(
					INT, value1.longValue() + value2.longValue());

		// 否则使用通用的浮点数加法
		return ExpValue.valueOf(
				FLOAT, value1.doubleValue() + value2.doubleValue());
	}

	/**
	 * 减法运算
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param allInt
	 * @param value1
	 * @param value2
	 * @return
	 * @exception
	 */
	private ExpValue reduce(boolean allInt, Number value1, Number value2)
	{
		// 如果都是整数，使用整数减法
		if (allInt)
			return ExpValue.valueOf(
					INT, value1.longValue() - value2.longValue());

		// 否则使用通用的浮点数减法
		return ExpValue.valueOf(
				FLOAT, value1.doubleValue() - value2.doubleValue());
	}
}
