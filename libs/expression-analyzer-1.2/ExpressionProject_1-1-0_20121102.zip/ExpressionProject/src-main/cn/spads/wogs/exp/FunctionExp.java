/**
 * 公式解析系统
 * Function.java independently from 2012-10-11 下午01:46:43
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

import static cn.spads.wogs.exp.Expression.Type.FUNCTION;

import java.util.ArrayList;
import java.util.List;

/**
 * 函数式
 * TODO summary..
 * This Function TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-11
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class FunctionExp extends VisibleItem implements Expression
{
	// Programmer comments for whole class.

	/** 函数名 */
	private String name;
	/** 参数表达式列表 */
	private List<Expression> params;

	FunctionExp(String text, String funcName)
	{
		super(text);
		if (funcName == null) throw new ExpException("No function name.");
		this.name = funcName;
		this.params = new ArrayList<Expression>(3);
	}

	/**
	 * 增加参数
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param param
	 * @exception
	 */
	public void addParam(Expression param)
	{
		if (param == null) throw new ExpException("Null params.");
		this.params.add(param);
	}

	/**
	 * 获取表达式类型
	 * 函数式的类型为 {@link #FUNCTION} 。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.Expression#getType()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	public Type getType()
	{
		return FUNCTION;
	}

	/**
	 * 获取函数名
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public String getFunctionName()
	{
		return this.name;
	}

	/**
	 * 获取参数个数
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public int paramCount()
	{
		return this.params.size();
	}

	/**
	 * 获取指定位置参数表达式
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param index
	 * @return
	 * @exception
	 */
	public Expression getParam(int index)
	{
		if (index < 0 || index >= this.params.size()) return null;
		return this.params.get(index);
	}

	/**
	 * <b>显示</b><br/>
	 * 如果尚未生成显示文本，则以空格为间隔逐一获取其各段的显示文本。若生成过，则
	 * 使用之前生成的记录。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.VisibleItem#toString()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	protected String generateDispText()
	{
		StringBuilder dispTextBuilder = new StringBuilder(this.name);
		dispTextBuilder.append('(');
		int paramCount = this.params.size();
		for (int index = -1; ++index != paramCount; )
			dispTextBuilder.append(this.params.get(index)).append(", ");
		if (paramCount != 0)
		{
			int redundantLength = dispTextBuilder.length();
			dispTextBuilder.delete(redundantLength - 2, redundantLength);
		}
		dispTextBuilder.append(')');
		return dispTextBuilder.toString();
	}
}
