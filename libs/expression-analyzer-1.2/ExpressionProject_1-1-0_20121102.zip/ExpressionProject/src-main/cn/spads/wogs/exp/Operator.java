/**
 * 公式解析系统
 * Operator.java independently from 2012-10-12 下午04:25:16
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

import static cn.spads.wogs.exp.Operator.Type.BINARY;
import static cn.spads.wogs.exp.Operator.Type.TERNARY;
import static cn.spads.wogs.exp.Operator.Type.UNARY;

/**
 * 运算符
 * TODO summary..
 * This Operator TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-12
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public enum Operator implements Item
{
	// Programmer comments for whole interface.

	/** 负号，也做逻辑“非”运算符 */
	NEGATIVE("-", 7, UNARY),
	/** 乘方 */
	POWER("^", 6),
	/** 阶乘 */
	FACTORIAL("!", 8, UNARY),

	/** 乘号 */
	MULTIPLE("*", 5),
	/** 除号 */
	DIVISION("/", 5),
	/** 求余运算符 */
	MOD("%", 5),

	/** 加号 */
	PLUS("+", 4),
	/** 减号 */
	MINUS("-", 4),

	/** 等号 */
	EQUAL("=", 3),
	/** 大于号 */
	GT(">", 3),
	/** 小于号 */
	LT("<", 3),

	/** 和运算符 */
	AND("&", 2),
	/** 或运算符 */
	OR("|", 1),

	/** 条件运算符 */
	COND("?", 0, TERNARY),
	/** 分支运算符 */
	BRANCH("~", 0, TERNARY)
	;

	/** 运算符类型 */
	private Type type;
	/** 运算符的文本 */
	private String text;
	/**
	 * 运算优先级
	 * 数值越大，运算优先级越高。
	 */
	private int level;

	private Operator(String text, int level, Type type)
	{
		this.text = text;
		this.level = level;
		this.type = type;
	}
	/**
	 * 如不特别说明，运算符都是双目运算符。
	 * TODO summary..
	 * The object will be created TODO ...
	 * @see
	 * @param text
	 * @param level
	 */
	private Operator(String text, int level)
	{
		this(text, level, BINARY);
	}

	/**
	 * 显示
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see java.lang.Enum#toString()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	public String toString()
	{
		return this.text;
	}

	/**
	 * 获取运算符文本
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.Item#getText()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	public String getText()
	{
		return this.text;
	}

	/**
	 * 获取运算优先级
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public int getLevel()
	{
		return this.level;
	}

	/**
	 * 获取运算符类型
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public Type getType()
	{
		return this.type;
	}

	/**
	 * 运算符类型
	 * TODO summary..
	 * This OperatorType TODO ...
	 * TODO Introduction of this class or interface etc.
	 * TODO Include the use in project, inner structure and using examples.
	 * @author		Shane Loo Li
	 * @version		1.1.0, 2012-10-18
	 * @see
	 * @since		Java 6.0, Diamond Lib 1.0
	 */
	static enum Type
	{
		/** 单目运算符 */
		UNARY,
		/** 双目运算符 */
		BINARY,
		/** 三目运算符 */
		TERNARY
	}
}
