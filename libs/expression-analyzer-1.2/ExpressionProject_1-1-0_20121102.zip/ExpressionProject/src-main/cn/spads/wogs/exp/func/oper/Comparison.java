/**
 * 公式解析系统
 * Comparison.java independently from 2012-10-25 上午09:09:59
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func.oper;
import static cn.spads.wogs.exp.ExpValue.ValueType.BOOL;
import static cn.spads.wogs.exp.ExpValue.ValueType.DATA;
import static cn.spads.wogs.exp.ExpValue.ValueType.FLOAT;
import static cn.spads.wogs.exp.ExpValue.ValueType.INT;
import static cn.spads.wogs.exp.ExpValue.ValueType.NULL;
import static cn.spads.wogs.exp.Operator.EQUAL;
import static cn.spads.wogs.exp.Operator.GT;
import static cn.spads.wogs.exp.Operator.LT;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import cn.spads.wogs.data.sys.DataObject;
import cn.spads.wogs.exp.ExpException;
import cn.spads.wogs.exp.ExpValue;
import cn.spads.wogs.exp.Operator;
import cn.spads.wogs.exp.ExpValue.ValueType;
import cn.spads.wogs.exp.func.Function;
import cn.spads.wogs.lang.JsonParser;


/**
 * 比较运算函数
 * TODO summary..
 * This Comparison TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-25
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class Comparison extends OperatorFunction implements Function, Comparator<ExpValue>
{
	// Programmer comments for whole class.

	/**
	 * 真值
	 */
	private final ExpValue trueValue;
	/**
	 * 假值
	 */
	private final ExpValue falseValue;
	/**
	 * 比较运算操作符列表
	 */
	private List<Operator> comparisonOperators;

	public Comparison()
	{
		this.trueValue = ExpValue.valueOf(BOOL, true);
		this.falseValue = ExpValue.valueOf(BOOL, false);
		this.comparisonOperators = new ArrayList<Operator>(3);
		this.comparisonOperators.add(GT);
		this.comparisonOperators.add(LT);
		this.comparisonOperators.add(EQUAL);
	}

	/**
	 * 获取比较运算操作符
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public List<Operator> getCorrespondingOperators()
	{
		return this.comparisonOperators;
	}

	/**
	 * 比较运算求值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.func.oper.OperatorFunction#evaluate(cn.spads.wogs.exp.Operator, cn.spads.wogs.exp.ExpValue[])
	 * @see
	 * @param oper
	 * @param params
	 * @return
	 * @exception
	 */
	@Override
	public ExpValue evaluate(Operator oper, ExpValue... params)
	{
		// 1 运算参数准备
		if (params.length != 2 || params[0] == null || params[1] == null)
			throw new ExpException("Comparision params wrong.");

		// 2 依据运算符进行比较运算
		switch (oper)
		{
			case GT:
				return this.compare(params[0], params[1]) > 0 ?
						this.trueValue : this.falseValue;
			case LT:
				return this.compare(params[0], params[1]) < 0 ?
						this.trueValue : this.falseValue;
			case EQUAL:
				return this.compare(params[0], params[1]) == 0 ?
						this.trueValue : this.falseValue;
		}

		// 3 如果不是逻辑运算符，则不进行运算，返回空值
		return ExpValue.valueOf(NULL, null);
	}

	/**
	 * <b>{@link ExpValue} 比较器</b><br/>
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see java.util.Comparator#compare(java.lang.Object, java.lang.Object)
	 * @see
	 * @param o1
	 * @param o2
	 * @return
	 * @exception
	 */
	@Override
	public int compare(ExpValue expValue1, ExpValue expValue2)
	{
		// null 值排在最后
		if (expValue1 == null || expValue2 == null)
			return expValue1 == null ? expValue2 == null ? 0 : 15 : -15;
		ValueType type1 = expValue1.type();
		ValueType type2 = expValue2.type();
		Object value1 = expValue1.value();
		Object value2 = expValue2.value();

		// NULL 类型的比较
		if (type1 == NULL || type2 == NULL)
			return type1 == NULL ? type2 == NULL ? 0 : 14 : -14;

		// 对于非 null 的排序
		switch (type1)
		{
			case DATA:
				if (type2 != DATA)
					throw new ExpException("DATA can't compare to " + type2);
				return this.compareData(value1, value2);
			case INT:
			case FLOAT:
				return this.compareNumber(type1, value1, type2, value2);
			case TEXT:
			case BOOL:
				if (type1 != type2)
					throw new ExpException(
							"Params types and values are not unified.");
				return this.compareValue(value1, value2);
		}
		throw new ExpException("Invalid comparision.");
	}

	/**
	 * 数据比较
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param type1
	 * @param value1
	 * @param type2
	 * @param value2
	 * @return
	 * @exception
	 */
	@SuppressWarnings("unchecked")
	private int compareData(Object value1, Object value2)
	{
		if (!(value1 instanceof String && value2 instanceof String))
			throw new ExpException("Params types and values are not unified.");
		JsonParser jsonParser = new JsonParser();
		Object dataObj1 = jsonParser.parseJson((String) value1);
		Object dataObj2 = jsonParser.parseJson((String) value2);
		if (dataObj1 instanceof DataObject && dataObj2 instanceof DataObject)
		{
			Object sortObj1 = ((DataObject) dataObj1).getDataMap().get("sort");
			Object sortObj2 = ((DataObject) dataObj2).getDataMap().get("sort");
			if (sortObj1 != null && sortObj2 != null
					&& sortObj1 instanceof Comparable
					&& sortObj2 instanceof Comparable)
				return ((Comparable<Object>) sortObj1).compareTo(sortObj2);
		}
		throw new ExpException("Incompared data.");
	}

	/**
	 * 数值比较
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param type1
	 * @param value1
	 * @param type2
	 * @param value2
	 * @return
	 * @exception
	 */
	private int compareNumber(ValueType type1, Object value1,
			ValueType type2, Object value2)
	{
		// 校验类型和值
		if (type2 != INT && type2 != FLOAT)
			throw new ExpException("Different value type can't be compared.");
		if (!(value1 instanceof Number && value2 instanceof Number))
			throw new ExpException("Params types and values are not unified.");

		// 求值
		Number num1 = (Number) value1;
		Number num2 = (Number) value2;
		if (type1 == INT && type2 == INT)
			return (int) (num1.longValue() - num2.longValue());
		if (num1.doubleValue() == num2.doubleValue()) return 0;
		if (num1.doubleValue() < num2.doubleValue()) return -3;
		return 3;
	}

	/**
	 * 可自然比较值的比较
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param type1
	 * @param value1
	 * @param type2
	 * @param value2
	 * @return
	 * @exception
	 */
	@SuppressWarnings("unchecked")
	private int compareValue(Object value1, Object value2)
	{
		if (!(value1 instanceof Comparable && value2 instanceof Comparable))
			throw new ExpException("Incompared value types.");
		Comparable<Object> compareBase = (Comparable<Object>) value1;
		return compareBase.compareTo(value2);
	}
}
