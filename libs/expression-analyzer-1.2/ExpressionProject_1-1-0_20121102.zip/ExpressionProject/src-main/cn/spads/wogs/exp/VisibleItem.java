/**
 * 公式解析系统
 * VisibleItem.java independently from 2012-10-17 下午05:48:17
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

/**
 * <b>可见项</b><br/>
 * 本项用以表示所有公式中可见的独立部分。包括表达式和运算符等。
 * TODO summary..
 * This VisibleItem TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-17
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
abstract public class VisibleItem implements Item
{
	// Programmer comments for whole class.

	/** 可见的文本 */
	private String text;
	/** 展示用字符串 */
	private String dispText;

	VisibleItem(String text)
	{
		this.text = text;
		this.dispText = null;
	}

	/**
	 * 获取表达式或运算符文本
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.Item#getText()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	public String getText()
	{
		return this.text;
	}

	/**
	 * 显示
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see java.lang.Object#toString()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	public String toString()
	{
		if (this.dispText != null) return this.dispText;
		return (this.dispText = this.generateDispText());
	}

	/**
	 * 生成显示用文本
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	protected String generateDispText()
	{
		return this.text;
	}
}
