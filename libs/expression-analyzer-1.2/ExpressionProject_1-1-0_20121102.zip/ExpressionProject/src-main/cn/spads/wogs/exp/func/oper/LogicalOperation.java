/**
 * 公式解析系统
 * LogicalOperation.java independently from 2012-10-25 上午12:44:08
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func.oper;

import static cn.spads.wogs.exp.ExpValue.ValueType.BOOL;
import static cn.spads.wogs.exp.ExpValue.ValueType.NULL;
import static cn.spads.wogs.exp.Operator.AND;
import static cn.spads.wogs.exp.Operator.OR;

import java.util.ArrayList;
import java.util.List;

import cn.spads.wogs.exp.ExpException;
import cn.spads.wogs.exp.ExpValue;
import cn.spads.wogs.exp.Operator;
import cn.spads.wogs.exp.func.Function;


/**
 * 逻辑运算函数
 * TODO summary..
 * This LogicalOperation TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-25
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class LogicalOperation extends OperatorFunction implements Function
{
	// Programmer comments for whole class.

	/**
	 * 逻辑运算操作符列表
	 */
	private List<Operator> locigalOperators;

	public LogicalOperation()
	{
		this.locigalOperators = new ArrayList<Operator>(2);
		this.locigalOperators.add(AND);
		this.locigalOperators.add(OR);
	}

	/**
	 * 获取逻辑运算操作符
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public List<Operator> getCorrespondingOperators()
	{
		return this.locigalOperators;
	}

	/**
	 * 逻辑运算求值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.func.oper.OperatorFunction#evaluate(cn.spads.wogs.exp.Operator, cn.spads.wogs.exp.ExpValue[])
	 * @see
	 * @param oper
	 * @param params
	 * @return
	 * @exception
	 */
	@Override
	public ExpValue evaluate(Operator oper, ExpValue... params)
	{
		// 1 运算参数准备
		if (params.length != 2 || params[0] == null || params[1] == null)
			throw new ExpException("Logical operation params wrong.");
		boolean value1 = (Boolean) this.logicReplace(params[0]).value();
		boolean value2 = (Boolean) this.logicReplace(params[1]).value();

		// 2 不同运算符返回不同的计算
		switch (oper)
		{
			// 并且运算
			case AND: return ExpValue.valueOf(BOOL, value1 && value2);

			// 或者运算
			case OR: return ExpValue.valueOf(BOOL, value1 || value2);
		}

		// 3 如果不是逻辑运算符，则不进行运算，返回空值
		return ExpValue.valueOf(NULL, null);
	}

	/**
	 * 将各种类型的值，转换为逻辑值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param orgValue
	 * @return
	 * @exception
	 */
	private ExpValue logicReplace(ExpValue orgValue)
	{
		switch (orgValue.type())
		{
			case DATA:
				return ExpValue.valueOf(BOOL, orgValue.value() != null
						&& ((String) orgValue.value()).trim().length() > 2);
			case TEXT:
				return ExpValue.valueOf(BOOL, orgValue.value() != null
						&& ((String) orgValue.value()).length() != 0);
			case INT:
			case FLOAT:
				return ExpValue.valueOf(BOOL,orgValue.value() != null
						&& ((Number) orgValue.value()).intValue() != 0);
			case BOOL: return orgValue;
			case NULL: return ExpValue.valueOf(BOOL, false);
		}
		throw new ExpException("Unexists value type: " + orgValue.type());
	}
}
