/**
 * 公式解析系统
 * Monomial.java independently from 2012-10-17 下午05:02:05
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

import cn.spads.wogs.exp.ExpValue.ValueType;
import static cn.spads.wogs.exp.Expression.Type.MONOMIAL;


/**
 * 单项式
 * TODO summary..
 * This Monomial TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-17
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class Monomial extends VisibleItem implements Expression
{
	// Programmer comments for whole class.

	/** 单项式值类型 */
	private ValueType type;

	Monomial(String text, ValueType type)
	{
		super(text);
		this.type = type;
	}

	/**
	 * 获取表达式类型
	 * 多项式的类型为 {@link #MONOMIAL} 。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.Expression#getType()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	public Type getType()
	{
		return MONOMIAL;
	}

	/**
	 * 获取值类型
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public ValueType getValueType()
	{
		return this.type;
	}
}
