/**
 * 公式解析系统
 * Probability.java independently from 2012-10-28 下午12:05:01
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func;

import cn.spads.wogs.exp.ExpException;
import cn.spads.wogs.exp.ExpValue;
import static cn.spads.wogs.exp.ExpValue.ValueType.NULL;


/**
 * <b>概率函数</b><br/>
 * TODO summary..
 * This Probability TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-28
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class Probability implements Function
{
	// Programmer comments for whole class.

	/**
	 * <b>计算概率函数的值</b><br/>
	 * 概率函数会将第一个参数理解为第二个参数出现的概率，将第三个参数理解为第四个参数
	 * 出现的概率。以这样的概率，选择出一个对应的结果。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.func.Function#evaluate(cn.spads.wogs.exp.ExpValue[])
	 * @see
	 * @param params
	 * @return
	 * @exception
	 */
	@Override
	public ExpValue evaluate(ExpValue... params)
	{
		// 1 校验参数
		if (params.length % 2 != 0)
			throw new ExpException("[Probability] Wrong params' count.");
		if (params.length == 0) return ExpValue.valueOf(NULL, null);

		// 2 获取传入的各几率
		int[] chances = new int[params.length / 2];
		Object chanceExpValue = null;
		double chanceValue = -1.0;
		int sum = 0;
		for (int index = -1; ++index != chances.length; )
		{
			chanceExpValue = params[index * 2].value();
			if (!(chanceExpValue instanceof Number))
				throw new ExpException(
						"[Probability] Wrong chance's params' type.");
			chanceValue = ((Number) chanceExpValue).doubleValue();
			sum += (chances[index] = (int) (chanceValue * 10000));
		}

		// 3 随机出一个结果
		int chanceIndex = new java.util.Random().nextInt(sum);
		sum = 0;
		for (int index = -1; ++index != chances.length; )
		{
			sum += chances[index];
			if (chanceIndex < sum) return params[index * 2 + 1];
		}

		// 4 如果随机结果没能生成，抛出运行异常
		throw new ExpException("[Probability] Running exception.");
	}
}
