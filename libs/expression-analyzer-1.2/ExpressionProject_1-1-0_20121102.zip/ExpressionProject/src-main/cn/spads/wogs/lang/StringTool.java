/**
 * 公式解析系统
 * StringTool.java independently from 2012-7-4 下午06:42:36
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.lang;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

/**
 * <b>自定义字符串处理工具</b><br/>
 * 这些字符串处理工具都在需要使用的局部优于 Java6.0 Development Kit 提供的程序。
 * TODO summary..
 * This StringTool TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-7-4
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class StringTool
{
	// Programmer comments for whole class.

	/**
	 * <b>简易字符串分割</b><br/>
	 * 本方法用来根据指定字符，将某字符串以此为分割，拆分成多个子字符串。
	 * 对于分割字符串功能，在 Java 6.0 以内，都只提供了支持正则表达式的
	 * {@link String#split(String) split} 方法。此方法为追求通用，即便是简单的
	 * 分割，也会基于正则表达式来进行。即便是编译过的正则表达式，其性能也无法与简单
	 * 的字符相等判断相提并论。<br/>
	 * 本方法不涉及正则表达式，通过遍历原字符串对应的字符数组来寻找符合分割字符的
	 * 字符，然后通过 {@link String#substring(int, int)} 来获取每一个分割字符之间
	 * 的子字符串，存入一个 {@link LinkedList} 中。这是一个功能简单但高效的方法。
	 * 如果规模比较大，拟考虑先通过一次循环，取得原字符串中分割字符的数量，以此制作
	 * 定长的 {@link ArrayList} 。
	 * 本方法尤其适用于常见的由半角逗号结合在一起的字符串的分割。<br/>
	 * 在编写之初，本方法曾采取将字符串的字符数组分段处理，通过系统字符串复制来形成
	 * 一个个子字符串。后经考证，{@link String#substring(int, int)} 是一个很高效的
	 * 方法，遂改。效率提高了一倍。
	 * 本方法使用示例如下：
	 * <pre>
	 * String source = "a b c d e f g h i j k l m n o p q r s t u v w x y z";
	 * List<String> secs = StringTool.splitSimpleString(source, ' ');</pre>
	 * 此示例中，{@link String} source 为原字符串。{@link List} secs 为删除空格后
	 * 的结果。
	 * @see		String#split(String)
	 * @see		String#substring(int, int)
	 * @param 	source	待被处理的字符串，即本方法的“原字符串”
	 * @param 	gap		分割字符
	 * @return		从指定原字符按分割字符拆分成的子字符串列表
	 * @exception	NullPointerException	当传入参数 source 为空时
	 */
	static public List<String> splitSimpleString(String source, char gap)
	{
		List<String> result = new LinkedList<String>();
		char[] sourceChars = source.toCharArray();
		String section = null;
		int startIndex = 0;
		for (int index = -1; ++index != sourceChars.length; )
		{
			if (sourceChars[index] != gap) continue;
			section = source.substring(startIndex, index);
			result.add(section);
			startIndex = index + 1;
		}
		section = source.substring(startIndex, sourceChars.length);
		result.add(section);
		return result;
	}

	/**
	 * 本方法用来求得字符串表达式实际的值，包括字符转义等。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param stringExpression
	 * @return
	 * @exception
	 */
	static public String stringValue(String stringExpression)
	{
		char[] allChars = stringExpression.toCharArray();
		int expressionLength = allChars.length;
		StringBuilder valueBuilder = new StringBuilder();
		char thisChar = 0;
		boolean escapingReady = false;
		if (allChars.length < 2 || allChars[0] != '"') return null;
		// 第一个字符必须是引号，不解析
		charscan: for (int index = 0; ++index != expressionLength; )
		{
			thisChar = allChars[index];

			// 处理转义状态下的字符
			if (escapingReady)
			{
				escapingReady = false;
				switch (thisChar)
				{
					// 单引号
					case '\'':
					// 双引号
					case '"':
					// 根号 - 转义号
					case '\\':
						valueBuilder.append(thisChar);
						continue;

					// 回车符
					case 'n': valueBuilder.append('\n'); continue;

					// 换行符
					case 'r': valueBuilder.append('\r'); continue;

					// 跳格符
					case 't': valueBuilder.append('\t'); continue;

					// 退格符
					case 'b':
						valueBuilder.deleteCharAt(valueBuilder.length() - 1);
						continue;

					// 十六进制状态
					case 'u':
					// 八进制状态
					case '0':
					case '1':
					case '2':
					case '3':
						int remainCharCount = expressionLength - index - 1;
						if (remainCharCount < 1) break charscan;
						if (remainCharCount > 4) remainCharCount = 4;
						// 如果是十六进制，则从下一位开始计数
						if (thisChar == 'u') index++;
						String numStr = stringExpression.substring(
								index, index + remainCharCount);
						valueBuilder.append(Integer.valueOf(
								numStr, thisChar == 'u' ? 16 : 8));
						index += remainCharCount - 1;
				}
				continue;
			}

			// 如果非转移状态，需要特殊处理的字符
			switch (thisChar)
			{
				// 准备开始转义
				case '\\':
					escapingReady = true;
					continue;

				// 发现非转义引号，本字符串结束
				case '"':
					break charscan;

				// 不需要特殊处理
				default:
					valueBuilder.append(thisChar);
			}
		}
		return valueBuilder.toString();
	}

	/**
	 * 本方法用来生成指定长度的字母、数字字符串，并避免形态上的近似
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param length
	 * @return
	 * @exception
	 */
	static public String generateRandomString(int length)
	{
		// 通过重复数字，增加数字在结果字符串中出现的频率。
		// 没有数字 0 和大写字母 O ；没有数字 1 、大写字母 I 和小写字母 l 。
		char[] baseChar = {'2', '3', '4', '5', '6', '7', '8', '9',
				'2', '3', '4', '5', '6', '7', '8', '9',
				'2', '3', '4', '5', '6', '7', '8', '9',
				'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N',
				'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
				'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'm', 'n',
				'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z'};
		Random ran = new Random();
		StringBuilder builder = new StringBuilder();
		while (length-- != 0)
			builder.append(baseChar[ran.nextInt(baseChar.length)]);
		return builder.toString();
	}

	/**
	 * 本方法用来将指定数值表达为二进制字符串。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param num
	 * @return
	 * @exception
	 */
	static public String getBinaryString(Number num)
	{
		if (num == null) return null;
		String result = "";
		StringBuilder byteBuilder = null;
		int bytesCount = 4;
		if (num instanceof Byte) bytesCount = 1;
		else if (num instanceof Short) bytesCount = 2;
		else if (num instanceof Long) bytesCount = 8;
		long value = num.longValue();
		for (int index = -1; ++index != bytesCount; )
		{
			int thisByte = (int) (value >> index * 8 & 0xFF);
			byteBuilder = new StringBuilder();
			for (int bit = 8; --bit != -1; )
				byteBuilder.append(thisByte >> bit & 0x01);
			result = byteBuilder.toString().concat(" ").concat(result);
		}
		return result;
	}

	/**
	 * <b>字符串删除其中某字符</b><br/>
	 * 本方法用来移除指定字符串中的指定字符。
	 * 在 Java 6.0 以内，删除字符串中的指定字符，需要通过
	 * {@link String#replace(CharSequence, CharSequence) replace} 方法，将指定单
	 * 字符的字符串，替换成空字符串来实现。而 <code>replace</code> 方法为了追求通用，
	 * 使用了正则表达式参数。即便是编译过的正则表达式，其性能也无法与简单的字符相等
	 * 判断相提并论。<br/>
	 * 本方法不涉及正则表达式，通过遍历原字符串对应的字符数组来寻找符合待删除字符的
	 * 字符，然后通过 {@link StringBuilder} 来实现删除。这是一个简单但高效的方法。
	 * <br/>
	 * 本方法使用示例如下：
	 * <pre>
	 * String source = "a b c d e f g h i j k l m n o p q r s t u v w x y z";
	 * String removed = StringTool.removeChar(source, ' ');</pre>
	 * 此示例中，{@link String} source 为原字符串。String removed 为删除空格后的
	 * 结果。
	 * @see		String#replace(CharSequence, CharSequence)
	 * @see		StringBuilder#deleteCharAt(int)
	 * @param 	source	待被处理的字符串，即本方法的“原字符串”
	 * @param 	target	需要从原字符串中移除的字符
	 * @return		从指定原字符串中移除指定字符后所得的结果字符串
	 * @exception	NullPointerException	当传入参数 source 为空时
	 */
	static public String removeChar(String source, char target)
	{
		StringBuilder builder = new StringBuilder(source);
		char[] srcChars = source.toCharArray();
		int accumulation = 0;
		for (int index = -1; ++index != srcChars.length; )
			if (srcChars[index] == target)
				builder.deleteCharAt(index - accumulation++);
		return builder.toString();
	}
}
