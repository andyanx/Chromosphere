/**
 * 公式解析系统
 * Variable.java independently from 2012-10-18 上午10:18:24
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

import static cn.spads.wogs.exp.Expression.Type.VARIABLE;

/**
 * 变量
 * TODO summary..
 * This Variable TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-18
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class Variable extends VisibleItem implements Expression
{
	// Programmer comments for whole class.

	/** 变量名 */
	private String name;

	Variable(String text)
	{
		super(text);
		this.name = text;
	}

	/**
	 * 获取表达式类型
	 * 函数式的类型为 {@link #VARIABLE} 。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.Expression#getType()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	public Type getType()
	{
		return VARIABLE;
	}

	/**
	 * 获取变量名
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public String getName()
	{
		return this.name;
	}
}
