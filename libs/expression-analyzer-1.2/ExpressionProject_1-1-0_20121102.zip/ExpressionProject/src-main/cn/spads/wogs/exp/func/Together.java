/**
 * 公式解析系统
 * Together.java independently from 2012-10-27 下午03:20:08
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func;

import static cn.spads.wogs.exp.ExpValue.ValueType.DATA;
import static cn.spads.wogs.exp.ExpValue.ValueType.TEXT;

import java.util.HashMap;
import java.util.Map;

import cn.spads.wogs.data.sys.SimpleDataObject;
import cn.spads.wogs.exp.ExpException;
import cn.spads.wogs.exp.ExpValue;
import cn.spads.wogs.lang.JsonBuilder;
import cn.spads.wogs.lang.JsonParser;


/**
 * 数据整合函数
 * TODO summary..
 * This Together TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-27
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class Together implements Function
{
	// Programmer comments for whole class.

	/**
	 * <b>计算合并函数的值</b><br/>
	 * 合并函数会将第一个参数理解为第二个参数的键，将第三个参数理解为第四个参数的键。
	 * 以此整理成 Json 文本。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.func.Function#evaluate(cn.spads.wogs.exp.ExpValue[])
	 * @see
	 * @param params
	 * @return
	 * @exception
	 */
	@Override
	public ExpValue evaluate(ExpValue... params)
	{
		if (params.length % 2 != 0)
			throw new ExpException("[Together]Wrong params' count.");
		final Map<String, Object> resultMap = new HashMap<String, Object>();
		boolean isKey = true;
		String key = null;
		for (ExpValue param: params)
		{
			if (isKey)
			{
				if (!(param.type() == TEXT && param.value() instanceof String))
					throw new ExpException(
							"[Together]Wrong name type: " + param.type());
				key = (String) param.value();
				isKey = false;
				continue;
			}
			switch (param.type())
			{
				case DATA:
					if (!(param.value() instanceof String))
						throw new ExpException(
								"[Together]Value doesn't match value type.");
					String dataStr = (String) param.value();
					resultMap.put(key,
							JsonParser.getInstance().parseJson(dataStr));
					break;
				case TEXT:
					if (!(param.value() instanceof String))
						throw new ExpException(
								"[Together]Value doesn't match value type.");
					resultMap.put(key, (String) param.value());
					break;
				case INT:
				case FLOAT:
				case BOOL:
					resultMap.put(key, param.value().toString());
					break;
				case NULL:
					resultMap.put(key, null);
			}
			isKey = true;
		}
		String resultValue = JsonBuilder.getInstance().buildJson(
				new SimpleDataObject()
				{
					public Map<String, Object> getDataMap()
					{
						return resultMap;
					}
				}
			);
		return ExpValue.valueOf(DATA, resultValue);
	}
}
