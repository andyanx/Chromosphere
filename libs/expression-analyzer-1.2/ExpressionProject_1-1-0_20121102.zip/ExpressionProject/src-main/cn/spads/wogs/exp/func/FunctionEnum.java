/**
 * 公式解析系统
 * FunctionEnum.java independently from 2012-10-26 下午05:24:03
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func;

import static cn.spads.wogs.exp.ExpValue.ValueType.DATA;

/**
 * TODO summary..
 * This FunctionEnum TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-26
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public enum FunctionEnum
{
	// Programmer comments for whole enum.
	/**
	 * 合并函数，将很多带名字的值组合成 {@link #DATA} 类型。
	 */
	TOGETHER(new Together()),

	/**
	 * 集合函数，讲很多值组合成 {@link List} 类型。
	 */
	JOINT(new Joint()),

	/**
	 * 随机函数，能够生成 0 - 1 之间的一个小数。
	 * 如果填写参数，则生成 0 - 参数值之间的一个整数。
	 */
	RANDOM(new Random()),

	/**
	 * 计算概率函数的值
	 * 概率函数会将第一个参数理解为第二个参数出现的概率，将第三个参数理解为第四个参数
	 * 出现的概率。以这样的概率，选择出一个对应的结果。
	 */
	SELECT(new Probability())
	;

	/**
	 * 其对应的函数程序对象
	 */
	private Function function;

	private FunctionEnum(Function function)
	{
		this.function = function;
	}

	/**
	 * 获取对应的函数程序对象。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public Function getFunction()
	{
		return this.function;
	}
}
