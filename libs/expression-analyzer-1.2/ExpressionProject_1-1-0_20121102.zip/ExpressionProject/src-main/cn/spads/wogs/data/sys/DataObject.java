/**
 * 公式解析系统
 * DataObject.java independently from 2012-4-8 上午03:11:18
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.data.sys;

import java.util.Map;

import cn.spads.wogs.lang.JsonBuilder;


/**
 * <b>数据对象接口</b><br/>
 * 本接口用以描述每日限免精选中的数据对象。最终数据将通过 {@link Map}<{@link String},
 * {@link Object}> 来表现。在实用过程中，数据对象将用于直接将数据内容通过
 * {@link JsonBuilder} 来生成 Json 字符串。此接口主要用于通过程序逐渐将生成、获取的
 * 数据记录进来；在一般的实现中，此接口规定的方法对数据的取出很难做到好的支持。<br/>
 * 一般来说，我们可以按照 Java Bean 的规范制作数据保存对象，比如：<br/>
 * <pre>
 * public class Person
 * {
 * 	private String name;
 * 	public void setName(String name) { this.name = name; }
 * 	public String getName() { return this.name; }
 * }
 * </pre>
 * 然后在此基础上实现 DataObject 接口：<br/>
 * <pre>
 * public class Person extends DataObject
 * {
 * 	private String name;
 * 	public void setName(String name) { this.name = name; }
 * 	public String getName() { return this.name; }
 * 	public Map<String, Object> getDataMap()
 * 	{
 * 		Map<String, Object> data = new java.util.HashMap<String, Object>();
 * 		data.put("name", this.name);
 * 		return data;
 * 	}
 * 	public void setData(String key, Object value)
 * 	{
 * 		if ("name".equals(key)) this.setName(value.toString();
 * 	}
 * 	public Object getData(String key)
 * 	{
 * 		if ("name".equals(key)) return this.getName();
 * 		return null;
 * 	}
 * }
 * </pre>
 * 这样的好处是数据存储对象可以根据实用情况，来决定将耗时过程集中在
 * {@link #getDataMap()} 里，还是通过制作私有 <code>Map</code> 成员变量以分散在
 * 每一次具体数据项的写入中。通过此例我们也可以看出，由于无法根据 <code>key</code>
 * 的内容转变<code>getData(String key)</code> 方法返回值的类型，所以不得不引入
 * 类型强制转换。这将给程序的健壮性造成非常大的隐患。所以郑重推荐程序内部通过传统
 * 的 getter 和 setter 方式记录、获取数据。<br/>
 * 
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-4-8 Sunday
 * @see			JsonBuilder#buildJson(Object)
 * @since		Java 6.0
 */
public interface DataObject
{
	/**
	 * 获取数据集映射。本方法不限定返回的数据集映射之来源，但要求通过
	 * {@link #setData(String, Object)} 记录的数据应包含在此映射中。另外对于无
	 * 数据项的情况，应返回空的 <code>Map</code> 而不是 <code>null</code> 。
	 * @return		数据集映射
	 */
	abstract public Map<String, Object> getDataMap();

	/**
	 * 注册数据。对于已存在键的重复写入，应覆盖掉原值。这意味着数据值必须能够接受
	 * <code>null</code> 。此方法并不要求一定有意义地实现，可以直接抛出
	 * {@link IllegalAccessException} 表明不可执行。
	 * @see			#getDataMap()
	 * @param key	数据对象中各种数据的键，可以理解为唯一标识。
	 * @param value	数据值。
	 * @exception	NullPointerException	如果 key == null 则抛出此异常。
	 */
	abstract public void setData(String key, Object value) throws IllegalAccessException;

	/**
	 * 获取数据。以 {@link Object} 方式获取数据。此方法并不要求一定有意义地实现，
	 * 可以直接抛出 {@link IllegalAccessException} 表明不可执行。
	 * @param key	数据对象中各种数据的键，可以理解为唯一标识。
	 * @return		指定键对应的数据
	 * @exception	NullPointerException	如果 key == null 则抛出此异常。
	 */
	abstract public Object getData(String key) throws IllegalAccessException;
}