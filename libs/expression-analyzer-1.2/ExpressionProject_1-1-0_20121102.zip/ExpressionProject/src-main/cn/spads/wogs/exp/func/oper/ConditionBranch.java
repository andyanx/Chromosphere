/**
 * 公式解析系统
 * ConditionBranch.java independently from 2012-10-24 下午05:52:58
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func.oper;

import cn.spads.wogs.exp.ExpException;
import cn.spads.wogs.exp.ExpValue;
import cn.spads.wogs.exp.func.Function;
import static cn.spads.wogs.exp.ExpValue.ValueType.BOOL;


/**
 * 条件分支
 * TODO summary..
 * This ConditionBranch TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-24
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class ConditionBranch implements Function
{
	// Programmer comments for whole class.

	/**
	 * 按条件进行分支
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see cn.spads.wogs.exp.func.oper.OperatorFunction#evaluate(cn.spads.wogs.exp.Operator, cn.spads.wogs.exp.ExpValue[])
	 * @see
	 * @param oper
	 * @param params
	 * @return
	 * @exception
	 */
	@Override
	public ExpValue evaluate(ExpValue... params)
	{
		if (params.length != 3 || params[0] == null || params[1] == null)
			throw new ExpException("Wrong params in condition branch.");
		ExpValue cond = params[0];
		if (cond == null || cond.type() != BOOL)
			throw new ExpException("Wrong condition type: " + cond.type());
		if ((Boolean) cond.value()) return params[1];
		return params[2];
	}
}
