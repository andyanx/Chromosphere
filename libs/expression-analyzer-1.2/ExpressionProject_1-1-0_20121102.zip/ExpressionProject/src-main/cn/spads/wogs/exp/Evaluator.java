/**
 * 公式解析系统
 * Evaluator.java independently from 2012-10-11 上午11:20:03
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

import static cn.spads.wogs.exp.ExpValue.ValueType.DATA;
import static cn.spads.wogs.exp.Operator.BRANCH;
import static cn.spads.wogs.exp.Operator.COND;

import java.util.Deque;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import cn.spads.wogs.exp.ExpValue.ValueType;
import cn.spads.wogs.exp.func.Function;
import cn.spads.wogs.lang.StringTool;


/**
 * 公式求值器
 * TODO summary..
 * This Evaluator TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-11
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class Evaluator
{
	// Programmer comments for whole class.

	/**
	 * 函数库
	 */
	private Map<String, Function> functionContext;
	/**
	 * 公式
	 */
	private String formula;
	/**
	 * 变量环境
	 */
	private Map<String, Expression> variableContext;
	/**
	 * 在求值变量集
	 */
	private Map<String, ExpValue> evaluatedVariables;

	/**
	 * 不允许被外界构造。
	 * TODO summary..
	 * The object will be created TODO ...
	 * @see
	 * @param formula
	 */
	Evaluator(Map<String, Function> functionContext, String formula)
	{
		this.functionContext = functionContext;
		this.formula = formula;
		this.variableContext = new HashMap<String, Expression>();
		this.evaluatedVariables = new HashMap<String, ExpValue>();
	}

	/**
	 * 计算全部公式总结果。
	 * 公式中，Result 变量为最终结果。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expressionTextt
	 * @return
	 * @exception
	 */
	public ExpValue evaluate()
	{
		List<String> formulaLines =
				StringTool.splitSimpleString(this.formula, '\n');
		for (String assignment: formulaLines)
		{
			int assignmentSymbolIndex = assignment.indexOf("?=");
			if (assignmentSymbolIndex == -1) continue;
			String variableName =
					assignment.substring(0, assignmentSymbolIndex).trim();
			String expText =
					assignment.substring(assignmentSymbolIndex + 2).trim();
			Expression exp = ExpressionFactory.INST
					.getExpressionFromText(expText);
			this.variableContext.put(variableName, exp);
		}
		Expression resultExp = this.variableContext.get("Result");
		if (resultExp == null) throw new ExpException("No result in formula.");
		return this.evaluateExpression(resultExp);
	}

	/**
	 * 计算表达式的值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expression	需要保证此参数非 null
	 * @return
	 * @exception
	 */
	private ExpValue evaluateExpression(Expression expression)
	{
		Expression.Type expressionType = expression.getType();
		switch (expressionType)
		{
			case VARIABLE:
				return this.evaluateVariable((Variable) expression);
			case MONOMIAL:
				return this.evaluateMonomial((Monomial) expression);
			case FUNCTION:
				return this.evaluateFunction((FunctionExp) expression);
			case MULTIPLE_EXPRESSION:
				return this.evaluateMultiExp((MultiExp) expression);
		}
		return null;
	}

	/**
	 * 计算变量式的值
	 * 本方法进行了循环调用的保护。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param variable
	 * @return
	 * @exception
	 */
	private ExpValue evaluateVariable(Variable expression)
	{
		String name = expression.getName();
		Expression variableContent = null;
		if (name == null
				|| (variableContent = this.variableContext.get(name)) == null)
			throw new ExpException("No such variable: ".concat(
					name == null ? "null" : name));
		ExpValue value = null;
		if (this.evaluatedVariables.containsKey(name))
		{
			value = this.evaluatedVariables.get(name);
			if (value == null)
				throw new ExpException("Nested variable evaluation.");
			else return value;
		}
		this.evaluatedVariables.put(name, null);
		value = this.evaluateExpression(variableContent);
		this.evaluatedVariables.put(name, value);
		return value;
	}

	/**
	 * 计算单项式的值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expression
	 * @return
	 * @exception
	 */
	private ExpValue evaluateMonomial(Monomial expression)
	{
		ValueType type = expression.getValueType();
		String monomialText = expression.getText();
		switch (type)
		{
			case DATA:
				return ExpValue.valueOf(type, expression.getText());
			case TEXT:
				return ExpValue.valueOf(type,
						StringTool.stringValue(monomialText));
			case INT:
				return ExpValue.valueOf(type, Long.valueOf(
						StringTool.removeChar(monomialText, ' ')));
			case FLOAT:
				return ExpValue.valueOf(type, Double.valueOf(
						StringTool.removeChar(monomialText, ' ')));
			case BOOL:
				return ExpValue.valueOf(type, Boolean.valueOf(monomialText));
			case NULL:
				return ExpValue.valueOf(type, null);
		}
		throw new ExpException("No such value type for: ".concat(monomialText));
	}

	/**
	 * 计算函数式的值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expression
	 * @return
	 * @exception
	 */
	private ExpValue evaluateFunction(FunctionExp expression)
	{
		String functionName = expression.getFunctionName();
		if (functionName == null) throw new ExpException("Null function name.");
		Function function = this.functionContext.get(functionName);
		if (function == null)
			throw new ExpException("No such function: ".concat(functionName));
		int paramCount = expression.paramCount();
		ExpValue[] paramValues = new ExpValue[paramCount];
		for (int index = -1; ++index != paramCount; )
			paramValues[index] =
					this.evaluateExpression(expression.getParam(index));
		return function.evaluate(paramValues);
	}

	/**
	 * 计算多项式的值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param expression	需要保证此参数非 null
	 * @return
	 * @exception
	 */
	private ExpValue evaluateMultiExp(MultiExp expression)
	{
		Deque<Operator> opers = new LinkedList<Operator>();
		Deque<ExpValue> exps = new LinkedList<ExpValue>();
		Iterator<Item> itemIterator = expression.getItemIterator();
		Item item = null;
		Operator lastOper = null;
		ExpValue operFuncValue = null;
		int branchTier = 0;

		// 解读多项式，按照运算优先级将可以先行计算的部分计算
		itemRead: while (itemIterator.hasNext())
		{
			item = itemIterator.next();

			// 如果是表达式则记录其值
			if (item instanceof Expression)
			{
				exps.addLast(this.evaluateExpression((Expression) item));
				continue itemRead;
			}

			// 如果不是表达式，也不是运算符，则忽略
			if (!(item instanceof Operator)) continue;

			// 运算符的有关处理
			while (true)
			{
				if (opers.size() == 0)
				{
					opers.addLast((Operator) item);
					continue itemRead;
				}
				lastOper = opers.getLast();
				if (((Operator) item).getLevel() > lastOper.getLevel())
				{
					opers.addLast((Operator) item);
					continue itemRead;
				}
				switch (lastOper.getType())
				{
					case UNARY:
					case BINARY:
						operFuncValue = this.evaluateOperation(lastOper, exps);
						break;
					case TERNARY:
						if (lastOper == COND)
						{
							branchTier++;
							opers.removeLast();
							opers.addLast((Operator) item);
							continue itemRead;
						}
						if (lastOper == BRANCH)
						{
							if (branchTier <= 0)
								throw new ExpException("Branch tier error.");
							branchTier--;
							operFuncValue = this.evaluateOperation(lastOper, exps);
						}
						break;
					default:
						throw new ExpException(
								"Wrong operator type: " + lastOper.getType());
				}
				// 将运算符函数式求得的值记录
				exps.addLast(operFuncValue);
				opers.removeLast();
			}
		}

		// 处理余下的运算
		while (opers.size() != 0)
			exps.addLast(this.evaluateOperation(opers.removeLast(), exps));
		if (exps.size() != 1) throw new ExpException("Wrong items' count.");
		return exps.getFirst();
	}

	/**
	 * 计算运算的值
	 * 本方法会根据运算符所需值的个数，从传入的值队列尾部，按照队列原先顺序取值。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param oper
	 * @param exps
	 * @return
	 * @exception
	 */
	private ExpValue evaluateOperation(Operator oper, Deque<ExpValue> exps)
	{
		Function operFunc = this.functionContext.get("_".concat(oper.name()));
		if (exps.size() < 1) throw new ExpException("Lack expression.");
		ExpValue last = exps.removeLast();
		ExpValue operValue = ExpValue.valueOf(DATA, oper);
		switch (oper.getType())
		{
			case UNARY:
				return operFunc.evaluate(operValue, last);
			case BINARY:
				return operFunc.evaluate(operValue, exps.removeLast(), last);
			case TERNARY:
				ExpValue trueBranch = exps.removeLast();
				ExpValue condition = exps.removeLast();
				return operFunc.evaluate(condition, trueBranch, last);
		}
		throw new ExpException("Wrong operator type: " + oper.getType());
	}
}
