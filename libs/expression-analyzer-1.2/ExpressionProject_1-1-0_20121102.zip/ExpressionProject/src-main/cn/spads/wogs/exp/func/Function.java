/**
 * 公式解析系统
 * Function.java independently from 2012-10-19 下午01:59:20
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp.func;

import cn.spads.wogs.exp.ExpValue;

/**
 * 可执行函数
 * TODO summary..
 * This Function TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * Entertainment Expression Framework
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-19
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public interface Function
{
	// Programmer comments for whole class.

	abstract public ExpValue evaluate(ExpValue... params);
}
