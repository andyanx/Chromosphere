/**
 * 公式解析系统
 * TestExpOperation.java independently from 2012-10-26 下午04:12:07
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.test;

import static cn.spads.wogs.exp.ExpValue.ValueType.BOOL;
import static cn.spads.wogs.exp.ExpValue.ValueType.DATA;
import static cn.spads.wogs.exp.ExpValue.ValueType.FLOAT;
import static cn.spads.wogs.exp.ExpValue.ValueType.INT;
import static cn.spads.wogs.exp.ExpValue.ValueType.NULL;
import static cn.spads.wogs.exp.ExpValue.ValueType.TEXT;

import java.util.Calendar;

import cn.spads.wogs.exp.ExpValue;
import cn.spads.wogs.exp.Operator;
import cn.spads.wogs.exp.func.Function;
import cn.spads.wogs.exp.func.oper.Arithmetic;
import cn.spads.wogs.exp.func.oper.Comparison;
import cn.spads.wogs.exp.func.oper.ConditionBranch;
import cn.spads.wogs.exp.func.oper.LogicalOperation;
import cn.spads.wogs.exp.func.oper.Rotation;


/**
 * 公式套件测试
 * TODO summary..
 * This TestExpOperation TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-26
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class TestExpOperation
{
	// Programmer comments for whole class.

	static private int loop = 3000000;

	static private ExpValue negativeValue = ExpValue.valueOf(DATA, Operator.NEGATIVE);
	static private ExpValue factorialValue = ExpValue.valueOf(DATA, Operator.FACTORIAL);

	static private ExpValue powValue = ExpValue.valueOf(DATA, Operator.POWER);
	static private ExpValue multipleValue = ExpValue.valueOf(DATA, Operator.MULTIPLE);
	static private ExpValue divisionValue = ExpValue.valueOf(DATA, Operator.DIVISION);
	static private ExpValue modValue = ExpValue.valueOf(DATA, Operator.MOD);
	static private ExpValue plusValue = ExpValue.valueOf(DATA, Operator.PLUS);
	static private ExpValue minusValue = ExpValue.valueOf(DATA, Operator.MINUS);

	static private ExpValue andValue = ExpValue.valueOf(DATA, Operator.AND);
	static private ExpValue orValue = ExpValue.valueOf(DATA, Operator.OR);

	static private ExpValue gtValue = ExpValue.valueOf(DATA, Operator.GT);
	static private ExpValue ltValue = ExpValue.valueOf(DATA, Operator.LT);
	static private ExpValue equalValue = ExpValue.valueOf(DATA, Operator.EQUAL);


	static private ExpValue dataValue = ExpValue.valueOf(DATA, "{\"groupName\":\"Spads\"}");
	static private ExpValue textValue = ExpValue.valueOf(TEXT, "Shane");
	static private ExpValue intValue = ExpValue.valueOf(INT, 15);
	static private ExpValue floatValue = ExpValue.valueOf(FLOAT, 14.73295832973294);
	static private ExpValue boolValue = ExpValue.valueOf(BOOL, false);
	static private ExpValue nullValue = ExpValue.valueOf(NULL, null);

	static public void main(String[] arguments)
	{
		testRotation();
		testConditionBranch();
		testArithmetic();
		testLogicalOperation();
		testComparison();
	}

	static private void testRotation()
	{
		Function f = new Rotation();

		System.out.println("---------- ---------- NEGATIVE TESTING --------- ----------");
		try
		{
			System.out.println("NEGATIVE: -{\"groupName\":\"Spads\"} = "
					+ f.evaluate(negativeValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("NEGATIVE: -\"Shane\" = "
					+ f.evaluate(negativeValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("NEGATIVE: -15 = "
					+ f.evaluate(negativeValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("NEGATIVE: -14.73295832973294 = "
					+ f.evaluate(negativeValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("NEGATIVE: -false = "
					+ f.evaluate(negativeValue, boolValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("NEGATIVE: -null = "
					+ f.evaluate(negativeValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 求负性能测试
		int index = -1;
		long t0 = Calendar.getInstance().getTimeInMillis();

		while (++index != loop) f.evaluate(negativeValue, intValue);
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数求负用时 " + (t1 - t0) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(negativeValue, floatValue);
		long t2 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次浮点数求负用时 " + (t2 - t1) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(negativeValue, boolValue);
		long t3 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次逻辑值求负用时 " + (t3 - t2) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(negativeValue, nullValue);
		long t4 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次空值求负用时 " + (t4 - t3) + "ms.");

		System.out.println("---------- ---------- FACTORIAL TESTING --------- ----------");
		try
		{
			System.out.println("FACTORIAL: {\"groupName\":\"Spads\"}! = "
					+ f.evaluate(factorialValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("FACTORIAL: \"Shane\"! = "
					+ f.evaluate(factorialValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("FACTORIAL: 15! = "
					+ f.evaluate(factorialValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("FACTORIAL: 14.73295832973294! = "
					+ f.evaluate(factorialValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("FACTORIAL: false! = "
					+ f.evaluate(factorialValue, boolValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("FACTORIAL: null! = "
					+ f.evaluate(factorialValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 阶乘性能测试
		long t5 = Calendar.getInstance().getTimeInMillis();

		index = -1;
		while (++index != loop) f.evaluate(factorialValue, intValue);
		long t6 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数阶乘用时 " + (t6 - t5) + "ms.");
	}

	static private void testConditionBranch()
	{
		Function f = new ConditionBranch();
		System.out.println("---------- ---------- BRANCH TESTING --------- ----------");
		try
		{
			System.out.println("? ~ 01: "
					+ f.evaluate(dataValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("? ~ 02: "
					+ f.evaluate(textValue, intValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("? ~ 03: "
					+ f.evaluate(intValue, boolValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("? ~ 04: "
					+ f.evaluate(floatValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("? ~ 05: "
					+ f.evaluate(ExpValue.valueOf(BOOL, true), intValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("? ~ 06: "
					+ f.evaluate(boolValue, boolValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("? ~ 07: "
					+ f.evaluate(nullValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 性能测试
		long t0 = Calendar.getInstance().getTimeInMillis();
		for (int index = -1; ++index != loop; )
			f.evaluate(boolValue, boolValue, nullValue);
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次分支用时 " + (t1 - t0) + "ms.");
	}

	static private void testArithmetic()
	{
		Function f = new Arithmetic();
		testPow(f);
		testMultiple(f);
		testDivision(f);
		testMod(f);
		testPlus(f);
		testMinus(f);
	}

	static private void testPow(Function f)
	{
		System.out.println("---------- ---------- POWER TESTING --------- ----------");
		try
		{
			System.out.println("15 ^ 15 = "
					+ f.evaluate(powValue, intValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 ^ 14.73295832973294 = "
					+ f.evaluate(powValue, intValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 ^ {\"groupName\":\"Spads\"} = "
					+ f.evaluate(powValue, intValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 ^ null = "
					+ f.evaluate(powValue, intValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("14.73295832973294 ^ 15 = "
					+ f.evaluate(powValue, floatValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 ^ 14.73295832973294 = "
					+ f.evaluate(powValue, floatValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 ^ \"Shane\" = "
					+ f.evaluate(powValue, floatValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 ^ null = "
					+ f.evaluate(powValue, floatValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("false ^ 15 = "
					+ f.evaluate(powValue, boolValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null ^ 14.73295832973294 = "
					+ f.evaluate(powValue, nullValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"groupName\":\"Spads\"} ^ \"Shane\" = "
					+ f.evaluate(powValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null ^ null = "
					+ f.evaluate(powValue, nullValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 次方性能测试
		int index = -1;
		long t0 = Calendar.getInstance().getTimeInMillis();

		while (++index != loop) f.evaluate(powValue, intValue, intValue);
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数次方用时 " + (t1 - t0) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(powValue, intValue, floatValue);
		long t2 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数的小数次方用时 " + (t2 - t1) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(powValue, floatValue, intValue);
		long t3 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次小数的整数次方用时 " + (t3 - t2) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(powValue, floatValue, floatValue);
		long t4 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次浮点数次方用时 " + (t4 - t3) + "ms.");
	}

	static private void testMultiple(Function f)
	{
		System.out.println("---------- ---------- MULTIPLE TESTING --------- ----------");
		try
		{
			System.out.println("15 * 15 = "
					+ f.evaluate(multipleValue, intValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 * 14.73295832973294 = "
					+ f.evaluate(multipleValue, intValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 * {\"groupName\":\"Spads\"} = "
					+ f.evaluate(multipleValue, intValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 * null = "
					+ f.evaluate(multipleValue, intValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("14.73295832973294 * 15 = "
					+ f.evaluate(multipleValue, floatValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 * 14.73295832973294 = "
					+ f.evaluate(multipleValue, floatValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 * \"Shane\" = "
					+ f.evaluate(multipleValue, floatValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 * null = "
					+ f.evaluate(multipleValue, floatValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("false * 15 = "
					+ f.evaluate(multipleValue, boolValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null * 14.73295832973294 = "
					+ f.evaluate(multipleValue, nullValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"groupName\":\"Spads\"} * \"Shane\" = "
					+ f.evaluate(multipleValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null * null = "
					+ f.evaluate(multipleValue, nullValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 乘法性能测试
		int index = -1;
		long t0 = Calendar.getInstance().getTimeInMillis();

		while (++index != loop) f.evaluate(multipleValue, intValue, intValue);
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数乘法用时 " + (t1 - t0) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(multipleValue, intValue, floatValue);
		long t2 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数乘以小数用时 " + (t2 - t1) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(multipleValue, floatValue, intValue);
		long t3 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次小数乘以整数用时 " + (t3 - t2) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(multipleValue, floatValue, floatValue);
		long t4 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次浮点数乘法用时 " + (t4 - t3) + "ms.");
	}

	static private void testDivision(Function f)
	{
		System.out.println("---------- ---------- DIVISION TESTING --------- ----------");
		try
		{
			System.out.println("15 / 15 = "
					+ f.evaluate(divisionValue, intValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 / 14.73295832973294 = "
					+ f.evaluate(divisionValue, intValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 / {\"groupName\":\"Spads\"} = "
					+ f.evaluate(divisionValue, intValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 / null = "
					+ f.evaluate(divisionValue, intValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("14.73295832973294 / 15 = "
					+ f.evaluate(divisionValue, floatValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 / 14.73295832973294 = "
					+ f.evaluate(divisionValue, floatValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 / \"Shane\" = "
					+ f.evaluate(divisionValue, floatValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 / null = "
					+ f.evaluate(divisionValue, floatValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("false / 15 = "
					+ f.evaluate(divisionValue, boolValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null / 14.73295832973294 = "
					+ f.evaluate(divisionValue, nullValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"groupName\":\"Spads\"} / \"Shane\" = "
					+ f.evaluate(divisionValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null / null = "
					+ f.evaluate(divisionValue, nullValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 除法性能测试
		int index = -1;
		long t0 = Calendar.getInstance().getTimeInMillis();

		while (++index != loop) f.evaluate(divisionValue, intValue, intValue);
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数除法用时 " + (t1 - t0) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(divisionValue, intValue, floatValue);
		long t2 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数除以小数用时 " + (t2 - t1) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(divisionValue, floatValue, intValue);
		long t3 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次小数除以整数用时 " + (t3 - t2) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(divisionValue, floatValue, floatValue);
		long t4 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次浮点数除法用时 " + (t4 - t3) + "ms.");
	}

	static private void testMod(Function f)
	{
		System.out.println("---------- ---------- MOD TESTING --------- ----------");
		try
		{
			System.out.println("15 % 15 = "
					+ f.evaluate(modValue, intValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 % 14.73295832973294 = "
					+ f.evaluate(modValue, intValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 % {\"groupName\":\"Spads\"} = "
					+ f.evaluate(modValue, intValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 % null = "
					+ f.evaluate(modValue, intValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("14.73295832973294 % 15 = "
					+ f.evaluate(modValue, floatValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 % 14.73295832973294 = "
					+ f.evaluate(modValue, floatValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 % \"Shane\" = "
					+ f.evaluate(modValue, floatValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 % null = "
					+ f.evaluate(modValue, floatValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("false % 15 = "
					+ f.evaluate(modValue, boolValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null % 14.73295832973294 = "
					+ f.evaluate(modValue, nullValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"groupName\":\"Spads\"} % \"Shane\" = "
					+ f.evaluate(modValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null % null = "
					+ f.evaluate(modValue, nullValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 求余性能测试
		int index = -1;
		long t0 = Calendar.getInstance().getTimeInMillis();

		while (++index != loop) f.evaluate(modValue, intValue, intValue);
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数求余用时 " + (t1 - t0) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(modValue, intValue, floatValue);
		long t2 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数对小数求余用时 " + (t2 - t1) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(modValue, floatValue, intValue);
		long t3 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次小数对整数求余用时 " + (t3 - t2) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(modValue, floatValue, floatValue);
		long t4 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次浮点数求余用时 " + (t4 - t3) + "ms.");
	}

	static private void testPlus(Function f)
	{
		System.out.println("---------- ---------- PLUS TESTING --------- ----------");
		try
		{
			System.out.println("15 + 15 = "
					+ f.evaluate(plusValue, intValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 + 14.73295832973294 = "
					+ f.evaluate(plusValue, intValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 + {\"groupName\":\"Spads\"} = "
					+ f.evaluate(plusValue, intValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 + null = "
					+ f.evaluate(plusValue, intValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("14.73295832973294 + 15 = "
					+ f.evaluate(plusValue, floatValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 + 14.73295832973294 = "
					+ f.evaluate(plusValue, floatValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 + \"Shane\" = "
					+ f.evaluate(plusValue, floatValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 + null = "
					+ f.evaluate(plusValue, floatValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("false + 15 = "
					+ f.evaluate(plusValue, boolValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null + 14.73295832973294 = "
					+ f.evaluate(plusValue, nullValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"groupName\":\"Spads\"} + \"Shane\" = "
					+ f.evaluate(plusValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null + null = "
					+ f.evaluate(plusValue, nullValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 加法性能测试
		int index = -1;
		long t0 = Calendar.getInstance().getTimeInMillis();

		while (++index != loop) f.evaluate(plusValue, intValue, intValue);
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数加法用时 " + (t1 - t0) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(plusValue, intValue, floatValue);
		long t2 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数加小数用时 " + (t2 - t1) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(plusValue, floatValue, intValue);
		long t3 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次小数加整数用时 " + (t3 - t2) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(plusValue, floatValue, floatValue);
		long t4 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次浮点数加法用时 " + (t4 - t3) + "ms.");
	}

	static private void testMinus(Function f)
	{
		System.out.println("---------- ---------- MINUS TESTING --------- ----------");
		try
		{
			System.out.println("15 - 15 = "
					+ f.evaluate(minusValue, intValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 - 14.73295832973294 = "
					+ f.evaluate(minusValue, intValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 - {\"groupName\":\"Spads\"} = "
					+ f.evaluate(minusValue, intValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 - null = "
					+ f.evaluate(minusValue, intValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("14.73295832973294 - 15 = "
					+ f.evaluate(minusValue, floatValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 - 14.73295832973294 = "
					+ f.evaluate(minusValue, floatValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 - \"Shane\" = "
					+ f.evaluate(minusValue, floatValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("14.73295832973294 - null = "
					+ f.evaluate(minusValue, floatValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		try
		{
			System.out.println("false - 15 = "
					+ f.evaluate(minusValue, boolValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null - 14.73295832973294 = "
					+ f.evaluate(minusValue, nullValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"groupName\":\"Spads\"} - \"Shane\" = "
					+ f.evaluate(minusValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null - null = "
					+ f.evaluate(minusValue, nullValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 减法性能测试
		int index = -1;
		long t0 = Calendar.getInstance().getTimeInMillis();

		while (++index != loop) f.evaluate(minusValue, intValue, intValue);
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数减法用时 " + (t1 - t0) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(minusValue, intValue, floatValue);
		long t2 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次整数减小数用时 " + (t2 - t1) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(minusValue, floatValue, intValue);
		long t3 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次小数减整数用时 " + (t3 - t2) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(minusValue, floatValue, floatValue);
		long t4 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次浮点数减法用时 " + (t4 - t3) + "ms.");
	}

	static private void testLogicalOperation()
	{
		Function f = new LogicalOperation();

		System.out.println("---------- ---------- AND TESTING --------- ----------");
		try
		{
			System.out.println("AND: {\"groupName\":\"Spads\"} && \"Shane\" = "
					+ f.evaluate(andValue, dataValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("AND: 15 && {} = "
					+ f.evaluate(andValue, intValue, ExpValue.valueOf(DATA, "{}")));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("AND: \"\" && 0 = "
					+ f.evaluate(andValue, ExpValue.valueOf(TEXT, ""), ExpValue.valueOf(INT, 0)));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 并且运算性能测试
		int index = -1;
		long t0 = Calendar.getInstance().getTimeInMillis();

		while (++index != loop) f.evaluate(andValue, dataValue, textValue);
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次 {\"groupName\":\"Spads\"} && \"Shane\" 用时 " + (t1 - t0) + "ms.");

		index = -1;
		while (++index != loop)
			f.evaluate(andValue, intValue, ExpValue.valueOf(DATA, "{}"));
		long t2 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次 15 && {} 用时 " + (t2 - t1) + "ms.");

		index = -1;
		while (++index != loop)
			f.evaluate(andValue, ExpValue.valueOf(TEXT, ""), ExpValue.valueOf(INT, 0));
		long t3 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次 \"\" && 0 用时 " + (t3 - t2) + "ms.");

		System.out.println("---------- ---------- OR TESTING --------- ----------");
		try
		{
			System.out.println("OR: 14.73295832973294 || {\"groupName\":\"Spads\"} = "
					+ f.evaluate(orValue, floatValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("OR: true || 0.0 = "
					+ f.evaluate(orValue, ExpValue.valueOf(BOOL, true), ExpValue.valueOf(FLOAT, 0.0)));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("OR: false || null = "
					+ f.evaluate(orValue, boolValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		// 或者运算性能测试
		long t4 = Calendar.getInstance().getTimeInMillis();

		index = -1;
		while (++index != loop) f.evaluate(orValue, floatValue, dataValue);
		long t5 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次 14.73295832973294 || {\"groupName\":\"Spads\"} 用时 " + (t5 - t4) + "ms.");

		index = -1;
		while (++index != loop)
			f.evaluate(orValue, ExpValue.valueOf(BOOL, true), ExpValue.valueOf(FLOAT, 0.0));
		long t6 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次 true || 0.0 用时 " + (t6 - t5) + "ms.");

		index = -1;
		while (++index != loop) f.evaluate(orValue, boolValue, nullValue);
		long t7 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次 false || null 用时 " + (t7 - t6) + "ms.");
	}

	static private void testComparison()
	{
		Function f = new Comparison();
		ExpValue data38 = ExpValue.valueOf(DATA, "{\"sort\":38}");
		ExpValue data51 = ExpValue.valueOf(DATA, "{\"sort\":51}");
		ExpValue textA = ExpValue.valueOf(TEXT, "\"A\"");
		ExpValue textB = ExpValue.valueOf(TEXT, "\"B\"");
		ExpValue int399 = ExpValue.valueOf(INT, 399);
		ExpValue float399 = ExpValue.valueOf(FLOAT, 399.0);
		ExpValue float399_2 = ExpValue.valueOf(FLOAT, 200 * 2.0 - 1);
		ExpValue trueValue = ExpValue.valueOf(BOOL, true);

		System.out.println("---------- ---------- DATA COMPARISON TESTING --------- ----------");
		try
		{
			System.out.println("{\"sort\":38} > {\"sort\":51} = "
					+ f.evaluate(gtValue, data38, data51));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"sort\":38} < {\"sort\":51} = "
					+ f.evaluate(ltValue, data38, data51));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"sort\":38} == {\"sort\":51} = "
					+ f.evaluate(equalValue, data38, data51));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"sort\":38} > {\"groupName\":\"Spads\"} = "
					+ f.evaluate(gtValue, data38, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("{\"sort\":38} < 15 = "
					+ f.evaluate(ltValue, data38, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		System.out.println("---------- ---------- TEXT COMPARISON TESTING --------- ----------");
		try
		{
			System.out.println("\"A\" > \"B\" = "
					+ f.evaluate(gtValue, textA, textB));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("\"A\" < \"B\" = "
					+ f.evaluate(ltValue, textA, textB));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("\"A\" == \"B\" = "
					+ f.evaluate(equalValue, textA, textB));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("\"Shane\" == 14.73295832973294 = "
					+ f.evaluate(equalValue, textValue, floatValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		System.out.println("---------- ---------- INT COMPARISON TESTING --------- ----------");
		try
		{
			System.out.println("15 > 399 = "
					+ f.evaluate(gtValue, intValue, int399));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 < 399 = "
					+ f.evaluate(ltValue, intValue, int399));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("15 == 399 = "
					+ f.evaluate(equalValue, intValue, int399));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("SPECIAL: 399 == 200 * 2.0 - 1 = "
					+ f.evaluate(equalValue, int399, float399_2));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("SPECIAL: 399 == 399.0 = "
					+ f.evaluate(equalValue, int399, float399));
		}
		catch (Exception ex) { System.out.println(ex); }

		System.out.println("---------- ---------- FLOAT COMPARISON TESTING --------- ----------");
		try
		{
			System.out.println("200 * 2.0 - 1 > 399.0 = "
					+ f.evaluate(gtValue, intValue, int399));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("200 * 2.0 - 1 < 399.0 = "
					+ f.evaluate(ltValue, intValue, int399));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("200 * 2.0 - 1 == 399.0 = "
					+ f.evaluate(equalValue, intValue, int399));
		}
		catch (Exception ex) { System.out.println(ex); }

		System.out.println("---------- ---------- BOOL COMPARISON TESTING --------- ----------");
		try
		{
			System.out.println("true > false = "
					+ f.evaluate(gtValue, trueValue, boolValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("true < false = "
					+ f.evaluate(ltValue, trueValue, boolValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("true == false = "
					+ f.evaluate(equalValue, trueValue, boolValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("false == 0 = "
					+ f.evaluate(equalValue, boolValue, ExpValue.valueOf(INT, 0)));
		}
		catch (Exception ex) { System.out.println(ex); }

		System.out.println("---------- ---------- NULL COMPARISON TESTING --------- ----------");
		try
		{
			System.out.println("null > {\"groupName\":\"Spads\"} = "
					+ f.evaluate(gtValue, nullValue, dataValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null < \"Shane\" = "
					+ f.evaluate(ltValue, nullValue, textValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null == 15 = "
					+ f.evaluate(equalValue, nullValue, intValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null > null = "
					+ f.evaluate(gtValue, nullValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null < null = "
					+ f.evaluate(ltValue, nullValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }
		try
		{
			System.out.println("null == null = "
					+ f.evaluate(equalValue, nullValue, nullValue));
		}
		catch (Exception ex) { System.out.println(ex); }

		// 通用功能测试
		int index = -1;
		ExpValue[] operators = {gtValue, ltValue, equalValue};
		ExpValue[] valuesA = {
				dataValue, textValue, intValue, floatValue, boolValue, nullValue,
				data38, data51, textA, textB, int399, float399, float399_2, trueValue
			};
		ExpValue[] valuesB = {
				dataValue, textValue, intValue, floatValue, boolValue, nullValue,
				data38, data51, textA, textB, int399, float399, float399_2, trueValue,
				ExpValue.valueOf(FLOAT, 399 / 7.0 * 7),
				ExpValue.valueOf(DATA, "{\"sort\":38.0}"),
				ExpValue.valueOf(DATA, "[\"sort\", 38]")
			};
		int operatorIndex = 0;
		int aIndex = 0;
		int bIndex = 0;
		ExpValue value = null;
		boolean exFlag = false;
		while (++index != 720)
		{
			try
			{
				value = f.evaluate(operators[operatorIndex], valuesA[aIndex], valuesB[bIndex]);
			}
			catch (Exception ex) { exFlag = true; }

			System.out.print(valuesA[aIndex] + " " + operators[operatorIndex] + " " + valuesB[bIndex] + " = ");
			System.out.print((exFlag ? "EXCEPTION" : value) + "\t");
			exFlag = false;
			if (index % 3 == 2) System.out.println();

			if (++operatorIndex == operators.length) operatorIndex = 0;
			if (++aIndex == valuesA.length) aIndex = 0;
			if (++bIndex == valuesB.length) bIndex = 0;
		}
		System.out.println();

		// 比较运算性能测试
		index = -1;
		operatorIndex = 0;
		aIndex = 0;
		bIndex = 0;
		long t0 = Calendar.getInstance().getTimeInMillis();
		while (++index != loop)
		{
			try
			{
				f.evaluate(operators[operatorIndex], valuesA[aIndex], valuesB[bIndex]);
			}
			catch (Exception ex) { }
			if (++operatorIndex == operators.length) operatorIndex = 0;
			if (++aIndex == valuesA.length) aIndex = 0;
			if (++bIndex == valuesB.length) bIndex = 0;
		}
		long t1 = Calendar.getInstance().getTimeInMillis();
		System.out.println(loop + " 次比较运算用时 " + (t1 - t0) + "ms.");
	}
}
