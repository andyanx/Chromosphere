/**
 * 公式解析系统
 * TestExp.java independently from 2012-10-19 下午12:03:14
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.test;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;

import cn.spads.wogs.exp.Evaluator;
import cn.spads.wogs.exp.EvaluatorFactory;
import cn.spads.wogs.exp.Expression;
import cn.spads.wogs.exp.ExpressionFactory;
import cn.spads.wogs.lang.StringTool;


/**
 * 公式套件测试
 * TODO summary..
 * This TestExp TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-19
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class TestExp
{
	// Programmer comments for whole class.
	static private String e1 = "Result ?= (3*8+5!*-2)\n";
	static private String e2 = "Dbc ?= RANDOM(100000)" + "\n"
			+ "Abc ?= RANDOM()" + "\n"
			+ "Result ?= 38 + 5/23*((    Abc + Dbc)*2882+53  )+ ( 2  )";
	static private String e3 = "Lv ?= 40" + "\n"
			+ "Result ?= Lv^3/(Lv)";
	static private String e4 = "Lv ?= 40" + "\n"
			+ "Age ?= 28" + "\n"
			+ "Result ?= RANDOM()  *(Lv^2+(20* Lv)+(1 000))*5 000%Age";
	static private String e5 = "Result ?= {\"name\": \"Shane Loo Li\",\"age\":288}";
	static private String e6 = "Lv ?= 40" + "\n"
			+ "Temp ?= Lv + 4" + "\n"
			+ "Result ?= RANDOM(100)/ 2 *2*((Lv^3/(Lv)) +20  *Lv+Temp^3)*50";
	static private String e7 = "Result ?= [{\"level\":1}, \"}\", 44, {}, {\"level\":\"{5}\"}]";
	static private String e8 = "Result ?= JOINT({\"type\": \"FLOAT\", \"value\": \"3.1415926535897932\"}, \"Bascketball\", 88)";
	static private String e9 = "A ?= B + 100" + "\n"
			+ "B ?= A + 1" + "\n"
			+ "Result ?= RANDOM(B)";
	static private String[] exps = {e1, e2, e3, e4, e5, e6, e7, e8, e9};

	static public void main(String[] arguments)
	{
		try { testExpGeneration(); }
		catch (Exception ex) { System.out.println(ex); }
		testSysFucntion();
	}

	static private void testExpGeneration()
			throws InvocationTargetException, IllegalAccessException
	{
		ExpressionFactory factory = ExpressionFactory.INST;
		for (String e: exps)
		{
			System.out.println("========== ========== ========== ==========");
			System.out.println("expText:\n" + e);
			System.out.println("---------- ---------- ---------- ----------");

			Expression.Type type = null;
			Class<ExpressionFactory> factoryClass = ExpressionFactory.class;
			Method[] allFactoryMethods = factoryClass.getDeclaredMethods();

			List<String> formulaLines =
				StringTool.splitSimpleString(e, '\n');
			for (String assignment: formulaLines)
			{
				int assignmentSymbolIndex = assignment.indexOf("?=");
				if (assignmentSymbolIndex == -1) continue;
				String expText =
						assignment.substring(assignmentSymbolIndex + 2).trim();
				// 测试求表达式类型
				for (Method m: allFactoryMethods)
				{
					m.setAccessible(true);
					if (m.getName().equals("checkExpType"))
						type = (Expression.Type) m.invoke(factory, expText);
				}
				System.out.println("type = " + type);
	
				// 测试识别表达式
				Expression exp = factory.getExpressionFromText(expText);
				System.out.println("expression:\t " + exp);
			}
			System.out.println("---------- ---------- ---------- ----------");
			Thread.yield();

			// 测试表达式求值
			System.out.println("value = " + EvaluatorFactory.INST.getEvaluator(e).evaluate());
			System.out.println("========== ========== ========== ==========");
		}
	}                                                                                                                                                                                        

	static private void testSysFucntion()
	{
		String testTogether = "Money ?= 6 000.00 * 12 + 500" + "\n"
				+ "Name ?= \"Shane\"" + "\n"
				+ "Company ?= {name: \"ETM\", \"totalPeople\": 400}" + "\n"
				+ "Result ?= TOGETHER(\"name\", Name, \"money\", Money, \"Company\", Company)" + "\n";
		String testStr = "Result ?= \"This is \\\"MY\\\" exception.\"";
		String testJoint = "Result ?= JOINT(\"te\\\"s\\\"t\", {Content:\"Haha, I am \\\"Shane\\\".\"}, 38 000)";
		String testRandom = "RanA ?= RANDOM()" + "\n"
			+ "RanB ?= RANDOM(38)" + "\n"
			+ "Result ?= TOGETHER(\"a\", RanA, \"b\", RanB)";

		String targetA = "Result ?= 38";
		String targetB = "Lv ?= 16\nResult ?= (Lv * Lv + 50 * Lv + 1000) * (RANDOM(10000) / 10000.0 + 0.5)";
		String targetC = "Result ?= 38 > 53 ? false ~ true ? 3 + 5 ~ 3 * 5";
		String[] sys = {
				targetC,
				targetA,
				targetB,
				testTogether, testStr, testRandom,
				testJoint
			};
		Evaluator e = null;
		for (String tested: sys)
		{
			e = EvaluatorFactory.INST.getEvaluator(tested);
			System.out.println(e.evaluate());
		}
	}
}
