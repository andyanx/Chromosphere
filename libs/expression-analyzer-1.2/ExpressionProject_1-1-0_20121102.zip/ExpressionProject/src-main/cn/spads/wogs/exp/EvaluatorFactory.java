/**
 * 公式解析系统
 * EvaluatorFactory.java independently from 2012-10-11 下午12:01:31
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

import static cn.spads.wogs.exp.Operator.BRANCH;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import cn.spads.wogs.exp.func.Function;
import cn.spads.wogs.exp.func.FunctionEnum;
import cn.spads.wogs.exp.func.oper.Arithmetic;
import cn.spads.wogs.exp.func.oper.Comparison;
import cn.spads.wogs.exp.func.oper.ConditionBranch;
import cn.spads.wogs.exp.func.oper.LogicalOperation;
import cn.spads.wogs.exp.func.oper.OperatorFunction;
import cn.spads.wogs.exp.func.oper.Rotation;


/**
 * 计算器工厂
 * TODO summary..
 * This EvaluatorFactory TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-11
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class EvaluatorFactory
{
	// Programmer comments for whole class.

	/**
	 * <b>单例对象</b><br/>
	 * 本对象的设计，考虑到日后支持多重函数库。如果有多种函数库，可做成枚举。
	 * 如果需要注入函数库，也可以取消单例。
	 */
	static public final EvaluatorFactory INST = new EvaluatorFactory();

	/**
	 * 函数库
	 */
	private Map<String, Function> functionContext;
	/**
	 * 计算器对象池
	 */
	private Map<String, Evaluator> evaluatorPool;

	private EvaluatorFactory()
	{
		this.registerFunctionContext();
		this.evaluatorPool = Collections.synchronizedMap(
				new HashMap<String, Evaluator>());
	}

	/**
	 * 注册函数环境
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @exception
	 */
	private void registerFunctionContext()
	{
		// 1 新建函数库
		this.functionContext = new HashMap<String, Function>();

		// 2 注册运算符函数
		OperatorFunction[] operFuncs = {new Arithmetic(), new Comparison(),
				new LogicalOperation(), new Rotation()};
		for (OperatorFunction operFunc: operFuncs)
			for (Operator oper: operFunc.getCorrespondingOperators())
				this.functionContext.put("_".concat(oper.name()), operFunc);
		// 这里需要注意，此处只注册 BRANCH 不注册 COND ，是和 Evaluator 算法耦合的
		this.functionContext.put("_".concat(BRANCH.name()), new ConditionBranch());

		// 3 注册本地函数
		for (FunctionEnum function: FunctionEnum.values())
			this.functionContext.put(function.name(), function.getFunction());
	}

	/**
	 * 获取计算器对象
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param formula
	 * @return
	 * @exception
	 */
	public Evaluator getEvaluator(String formula)
	{
		Evaluator evaluator = this.evaluatorPool.get(formula);
		if (evaluator == null)
		{
			evaluator = new Evaluator(this.functionContext, formula);
			if (this.evaluatorPool.size() >= 100) this.evaluatorPool.clear();
			this.evaluatorPool.put(formula, evaluator);
		}
		return evaluator;
	}
}
