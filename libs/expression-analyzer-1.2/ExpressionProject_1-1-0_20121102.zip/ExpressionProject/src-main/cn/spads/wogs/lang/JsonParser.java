/**
 * 公式解析系统
 * JsonParser.java independently from 2012-4-19 下午02:27:53
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.lang;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import cn.spads.wogs.data.sys.DataObject;


/**
 * TODO summary..
 * This JsonParser TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-4-19
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class JsonParser
{
	// Programmer comments for whole class.
	/**
	 * 获取对象。此为封装的多例模式，每次会返回新的对象。
	 * @return		本类新对象
	 */
	static public JsonParser getInstance() { return new JsonParser(); }

	/**
	 * 此方法返回的数据对象，本身是没有并发访问保护的。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param jsonStr
	 * @return
	 * @exception
	 */
	public Object parseJson(String jsonStr)
	{
		if (jsonStr == null || jsonStr.trim().length() == 0) return null;
		List<String> jsonSections;
		jsonStr = jsonStr.trim();
		switch (jsonStr.charAt(0))
		{
			case '{':
				jsonStr = this.truncBothEnds(jsonStr);
				jsonSections = this.jsonSplit(jsonStr);
				final Map<String, Object> jsonObj = new HashMap<String, Object>();
				for (String section: jsonSections)
				{
					section = section.trim();
					int keyLength = this.getObjSectionKeyLength(section);
					if (keyLength < 0) continue;
					String key = section.substring(0, keyLength).trim();
					if (key.charAt(0) == '"') key = this.truncBothEnds(key);
					String value = section.substring(keyLength);
					value = value.substring(value.indexOf(':') + 1);
					jsonObj.put(key, this.parseJson(value));
				}
				return new DataObject()
					{
						@Override
						public Map<String, Object> getDataMap()
						{
							return jsonObj;
						}

						@Override
						public void setData(String key, Object value)
								throws IllegalAccessException
						{
							jsonObj.put(key, value);
						}

						@Override
						public Object getData(String key)
								throws IllegalAccessException
						{
							return jsonObj.get(key);
						}
					};
			case '[':
				jsonStr = this.truncBothEnds(jsonStr);
				jsonSections = this.jsonSplit(jsonStr);
				List<Object> jsonArr = new ArrayList<Object>(jsonSections.size());
				for (String section: jsonSections)
				{
					section = section.trim();
					if (section.charAt(0) == '"')
						section = this.truncBothEnds(section.trim());
					jsonArr.add(this.parseJson(section));
				}
				return jsonArr;
			default:
				if (jsonStr.charAt(0) == '"')
					jsonStr = StringTool.stringValue(jsonStr);
				return jsonStr;
		}
	}

	/**
	 * 在此方法的算法中，如果key由引号包裹，并且在引号完毕之后和冒号开始之前有其余
	 * 非空字符则会被忽略。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param section
	 * @return		负数表示异常——传入的Json key:value对不合法
	 * @exception
	 */
	private int getObjSectionKeyLength(String section)
	{
		section = section.trim();
		if (section.charAt(0) != '"') return section.indexOf(':');
		for (int index = 0; ++index != section.length(); )
		{
			if (section.charAt(index) == '"' && section.charAt(index - 1) != '\\')
				return index + 1;
		}
		return -1;
	}

	/**
	 * 
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param str
	 * @return
	 * @exception StringIndexOutOfBoundsException	传入字符串长度不足2位，则抛出此异常
	 */
	private String truncBothEnds(String str)
	{
		return str.substring(1, str.length() - 1);
	}

	/**
	 * 本方法负责给数据对象或者数组进行分段，分段依据是顶层的逗号（,）。
	 * 当数据对象或数组无任何元素时返回空列表，即便有空白字符包含在括号中
	 * 也会被忽略。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param jsonStr
	 * @return
	 * @exception
	 */
	private List<String> jsonSplit(String jsonStr)
	{
		int leftSquareBranketCount = 0;
		int leftBraceCount = 0;
		int beginIndex = 0;
		boolean inQuotationPair = false;
		
		List<String> sections = new LinkedList<String>();
		for (int index = -1; ++index != jsonStr.length(); )
		{
			char thisChar = jsonStr.charAt(index);
			if (inQuotationPair)
			{
				// 考虑到初始状态 inQuotationPair 是 false ，所以避免了 index - 1 < 0 的情况。
				inQuotationPair = thisChar != '"' || jsonStr.charAt(index - 1) == '\\';
				continue;
			}
			// 对于不在引号中的情况，考查 Json 关键字符
			switch (thisChar)
			{
				case '"':
					char before = jsonStr.charAt(index != 0 ? index - 1 : index);
					if (before != '\\') inQuotationPair = !inQuotationPair;
					break;
				case '{': leftBraceCount++; break;
				case '}': leftBraceCount--; break;
				case '[': leftSquareBranketCount++; break;
				case ']': leftSquareBranketCount--; break;
				case ',': 
					if (leftBraceCount == 0 && leftSquareBranketCount == 0)
					{
						sections.add(jsonStr.substring(beginIndex, index));
						beginIndex = index + 1;
					}
			}
		}
		String lastSection = jsonStr.substring(beginIndex, jsonStr.length());
		if (lastSection.trim().length() != 0) sections.add(lastSection);
		return sections;
	}
}

