/**
 * 公式解析系统
 * JsonBuilder.java independently from 2012-4-8 上午03:11:18
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.lang;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import cn.spads.wogs.data.sys.DataObject;


/**
 * <b>对象符号（Json）生成器</b><br/>
 * 本类对象用来将 {@link Collection} 或 {@link DataObject} 以对象符号（Json）表示。对于
 * 其中包含的元素，除数字之外，无论是数据键还是其它类型数据，都会以双引号包括起来。
 * 本类对象非线程安全，每一个对象只应该用以建立一个对象符号（Json）。调用方法如下。
 * <pre>
 * Collection list = Xxx.getXxxXxxx();
 * String json = JsonBuilder.getInstance().buildJson(list);
 * </pre>
 * 其中 {@link #getInstance()} 可以保证每次返回不同的对象。最好不要用引用变量将其
 * 保存下来，而是随生成随使用。
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-4-8 Sunday
 * @see			DataObject
 * @see			#buildJson(Object)
 * @since		Java 6.0
 */
public class JsonBuilder
{
	// 本项目服务器和苹果交互，所有传送给苹果客户端的数据，都由本类生成。
	// 在编写过程中，尤其需要注意内存占用和执行效率。

	/**
	 * 获取对象。此为封装的多例模式，每次会返回新的对象。
	 * @return		本类新对象
	 */
	static public JsonBuilder getInstance() { return new JsonBuilder(); }
	/**
	 * 封装的构造方法禁止外部直接创建新对象，能一定程度减少调用混乱。
	 * @see	#getInstance()
	 */
	private JsonBuilder()
	{
		this.builder = new StringBuilder();
	}

	/**
	 * 字符串生成器。对象符号（Json）本质上就是一个字符串。本成员用以高效生成所需
	 * 的字符串。
	 */
	private StringBuilder builder;

	/**
	 * 清除构造器内部数据
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public JsonBuilder clear()
	{
		this.builder.delete(0, this.builder.length());
		return this;
	}

	/**
	 * 构造对象符号（Json）。仅当传入的对象为 {@link DataObject} 或者 {@link Collection}
	 * 时，才会有对象符号字符串返回值。如果传入的对象不是此二种类型，则会得到
	 * <code>null</code> 。这么设计是为了提高此方法内部调用的效率，也不会影响真实
	 * 情况下的使用。本方法内部通过调用其它方法积累对象符号，具体积累方式根据传入
	 * 参数类型不同而有所不同。对于不可识别的类型（包括{@link String}），则通过
	 * 调用其 {@link #toString()} 来当做字符串表示。字符串值前后会追加双引号。
	 * <br/>数据对象 <code>DataObject</code> 和列表 <code>Collection</code> 的对象符号
	 * 格式不同。数据对象的对象符号是一个以 <code>{</code> 开始，以 <code>}</code>
	 * 结束的字符串；其中各个数据项之间用 <code>,</code> 间隔；每个数据项是一个键值
	 * 对，其中键都是用 <code>"</code>括起来的字符串，键后边有一个 <code>:</code> 。
	 * <pre>
	 * {
	 * 	"name":"Entertainment Ltd.",
	 * 	"version":1,
	 * 	"employee":["A","B"],
	 * 	"address":{"contry":"China","city":"Beijing"}
	 * }
	 * </pre>
	 * 列表的对象符号是一个以 <code>{</code> 开始，以 <code>}</code>结束的字符串；
	 * 其中各个数据项之间用 <code>,</code> 间隔。一般来说，列表中各项应具备同种
	 * 格式。
	 * <pre>
	 * 例甲：[2,5,8,10]
	 * 例乙：["Sunshine","Dioskouri","Athena"]
	 * 例丙：[{"name":"A",age:30},{"name":"B",age:20}]
	 * </pre>
	 * @see			#buildJson(DataObject)
	 * @see			#buildJson(Collection)
	 * @see			#buildJson(Number)
	 * @see			#buildJson(Object)
	 * @param 		obj	用来生成对象符号的数据对象
	 * @return		传入参数所挟数据的对象符号
	 */
	public String buildJson(Object obj)
	{
		if (obj == null)
		{
			this.builder.append("\"\"");	// 如果对象符号（Json）为空，不应该什么都不反回，所以决定提供空字符串。
			return null;	// 因为数值类型求对象符号（Json）只可能是内部调用，所以不需要返回值。
		}
		else if (obj instanceof DataObject) this.buildJson((DataObject) obj);
		else if (obj instanceof Collection) this.buildJson((Collection<?>) obj);
		else if (obj instanceof Number)
		{
			this.buildJson((Number) obj);
			return null;	// 因为数值类型求对象符号（Json）只可能是内部调用，所以不需要返回值。
		}
		else
		{
			String str = obj.toString().replace("\"", "\\\"");
			this.builder.append('\"').append(str).append('\"');
			return null;	// 因为数值类型求对象符号（Json）只可能是内部调用，所以不需要返回值。
		}
		return builder.toString();
	}

	/**
	 * 对数据对象 {@link DataObject} 类对象构造对象符号（Json），追加在缓存中。
	 * 数据对象的对象符号是一个以 <code>{</code> 开始，以 <code>}</code> 结束的
	 * 字符串；其中各个数据项之间用 <code>,</code> 间隔；每个数据项是一个键值对，
	 * 其中键都是用 <code>"</code> 括起来的字符串，键后边有一个 <code>:</code> 。
	 * 示例如下。
	 * <pre>
	 * {
	 * 	"name":"Entertainment Ltd.",
	 * 	"version":1,
	 * 	"employee":["A","B"],
	 * 	"address":{"contry":"China","city":"Beijing"}
	 * }
	 * </pre>
	 * @param 		dataObj	具有数据集映射的数据对象
	 * @exception	NullPointerException	当传入 <code>dataObj</code>
	 * 获取到的数据映射为 <code>null</code> 时抛出此异常。
	 */
	private void buildJson(DataObject dataObj)
	{
		this.builder.append('{');
		Map<String, Object> dataMap = dataObj.getDataMap();
		Set<String> keys = dataMap.keySet();
		Iterator<String> keyIterator = keys.iterator();
		while(keyIterator.hasNext())
		{
			String key = keyIterator.next();
			this.builder.append('\"').append(key).append("\":");
			this.buildJson(dataMap.get(key));
			this.builder.append(',');
		}
		if (!keys.isEmpty())
			this.builder.deleteCharAt(this.builder.length() - 1);
		this.builder.append('}');
	}

	/**
	 * 对列表 {@link Collection} 类对象构造对象符号（Json），追加在缓存中。列表的对象
	 * 符号是一个以 <code>{</code> 开始，以 <code>}</code>结束的字符串；其中各个
	 * 数据项之间用 <code>,</code> 间隔。一般来说，列表中各项应具备同种格式。
	 * 示例如下。
	 * <pre>
	 * 例甲：[2,5,8,10]
	 * 例乙：["Sunshine","Dioskouri","Athena"]
	 * 例丙：[{"name":"A",age:30},{"name":"B",age:20}]
	 * </pre>
	 * @see
	 * @param 		dataList	数据列表
	 */
	private void buildJson(Collection<?> dataList)
	{
		this.builder.append('[');
		for (Object dataElement: dataList)
		{
			// TODO 需要检测诸如 ["xy","ab",,"cd"] 这样的列表是否合法，
			// 以决定要不要对于 null 的dataElement抛出空指针异常。
			this.buildJson(dataElement);
			this.builder.append(',');
		}
		if (!dataList.isEmpty())
			this.builder.deleteCharAt(this.builder.length() - 1);
		this.builder.append(']');
	}

	/**
	 * 对数值 {@link Number} 类对象构造对象符号（Json），追加在缓存中。所指定的
	 * 数值将会被理解为具体的数，而不是数值对象本身。
	 * @param 		num	待构造对象符号的数值
	 */
	private void buildJson(Number num)
	{
		this.builder.append(num.toString());
	}
}