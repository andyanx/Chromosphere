/**
 * 公式解析系统
 * ExpValue.java independently from 2012-10-17 下午04:00:14
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.exp;

import static cn.spads.wogs.exp.ExpValue.ValueType.BOOL;
import static cn.spads.wogs.exp.ExpValue.ValueType.NULL;

/**
 * 公式的值
 * TODO summary..
 * This ExpValue TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-17
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class ExpValue
{
	// Programmer comments for whole class.

	/**
	 * 缓存最常见的几个 ExpValue 对象。
	 */
	static private ExpValue[] valuePool =
			{
				new ExpValue(NULL, null),
				new ExpValue(BOOL, Boolean.TRUE),
				new ExpValue(BOOL, Boolean.FALSE)
			};

	/**
	 * 获取 ExpValue 对象。如果是非常常见的值，则从对象池中获取。
	 * 目前，空值以及逻辑值的真、假，都是固定对象。
	 * 另外，无论指定值类型如何，当值本身为 null 的时候，值类型都会转换为 NULL 。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param valueType
	 * @param value
	 * @return
	 * @exception
	 */
	static public ExpValue valueOf(ValueType valueType, Object value)
	{
		if (valueType == NULL || value == null) return ExpValue.valuePool[0];
		if (valueType == BOOL)
			return ExpValue.valuePool[(Boolean) value ? 1 : 2];
		return new ExpValue(valueType, value);
	}

	/** 当前公式值的类型 */
	private final ValueType valueType;
	/** 当前公式值本身 */
	private final Object value;

	public ExpValue(ValueType valueType, Object value)
	{
		this.valueType = valueType;
		switch (valueType)
		{
			case INT:
				this.value = Long.valueOf(((Number) value).longValue());
				break;
			case FLOAT:
				this.value = Double.valueOf(((Number) value).doubleValue());
				break;
			default:
				this.value = value;
		}
	}

	/**
	 * 获取公式值类型
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public ValueType type()
	{
		return this.valueType;
	}

	/**
	 * 获取公式值
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	public Object value()
	{
		return this.value;
	}

	/**
	 * 显示
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see java.lang.Object#toString()
	 * @see
	 * @return
	 * @exception
	 */
	@Override
	public String toString()
	{
		return this.value == null ? "null" : this.value.toString();
	}

	/**
	 * 公式值类型
	 * TODO summary..
	 * This ValueType TODO ...
	 * TODO Introduction of this class or interface etc.
	 * TODO Include the use in project, inner structure and using examples.
	 * @author		Shane Loo Li
	 * @version		1.1.0, 2012-10-18
	 * @see
	 * @since		Java 6.0, Diamond Lib 1.0
	 */
	static public enum ValueType
	{
		/**
		 * <b>数据</b><br/>
		 * 内部存储为 Json 字符串。
		 */
		DATA,

		/** 文本 */
		TEXT,

		/** 整数 */
		INT,

		/** 小数 */
		FLOAT,

		/** 逻辑值 */
		BOOL,

		/** 空值 */
		NULL
	}
}
