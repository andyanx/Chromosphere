/**
 * 公式解析系统
 * NumberTool.java independently from 2012-10-20 上午11:19:51
 * ---------- ---------- ---------- ----------
 * Copyright(c) 2012-2022 Spads
 * E-mail: Surmounting@gmail.com
 * ---------- ---------- ---------- ----------
 * 公式解析系统能够计算各种算术运算、逻辑运算和比较运算，可以连接本地函数，支持括号
 * 分级，允许逐级设置公式内临时变量，提供了分支运算符，并且支持 Json 数据格式的运算。
 */
package cn.spads.wogs.lang;

/**
 * <b>自定义数值处理工具</b><br/>
 * 这些数值处理工具都在需要使用的局部优于 Java6.0 Development Kit 提供的程序。
 * This NumberTool TODO ...
 * TODO Introduction of this class or interface etc.
 * TODO Include the use in project, inner structure and using examples.
 * @author		Shane Loo Li
 * @version		1.1.0, 2012-10-20
 * @see
 * @since		Java 6.0, Diamond Lib 1.0
 */
public class NumberTool
{
	// Programmer comments for whole class.

	/**
	 * <b>整数次方</b><br/>
	 * 本方法要求底数和指数都为整数。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @return
	 * @exception
	 */
	static public long intPow(int base, int exponent)
	{
		long pow = 1;
		while (exponent-- > 0) pow *= base;
		return pow;
	}

	/**
	 * <b>阶乘</b><br/>
	 * 负数的阶乘为其取负得到的正数阶乘后再取负。
	 * 0 的阶乘是 0 。
	 * TODO summary..
	 * This method TODO ...
	 * [ TODO example ]
	 * @see
	 * @param base
	 * @return
	 * @exception
	 */
	static public long factorial(int base)
	{
		if (base == 0) return 0;
		boolean change = base < 0;
		if (change) base = -1 * base;
		long product = 1;
		for (int index = 0; index++ != base; )
			product *= index;
		return change ? -1 * product : product;
	}
}
